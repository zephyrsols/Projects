package yxcorp.gifshow.util

import android.content.Context

object CPU {
    init {
        System.loadLibrary("core")
    }

    external fun getCheckRes(context: Context?, i: Int): Int
    external fun getClock(context: Context?, bArr: ByteArray?, i: Int): String?
    external fun getMagic(context: Context?, i: Int): String?
    @Synchronized
    fun getMagicData(context: Context?, i: Int): String? {
        var magic: String?
        val cls = CPU::class.java
        synchronized(cls) { synchronized(cls) { magic = getMagic(context, i) } }
        return magic
    }

    @Synchronized
    fun getClockData(context: Context?, bArr: ByteArray?, i: Int): String? {
        var clock: String?
        val cls = CPU::class.java
        synchronized(cls) { synchronized(cls) { clock = getClock(context, bArr, i) } }
        return clock
    }

    @Synchronized
    fun getCheckResData(context: Context?, i: Int): Int {
        var checkRes: Int
        val cls = CPU::class.java
        synchronized(cls) { synchronized(cls) { checkRes = getCheckRes(context, i) } }
        return checkRes
    }
}