package com.example.allinonestatussaver.interfaces

import java.io.File

interface FileListClickInterface {
    fun getPosition(position: Int, file: File?)
}