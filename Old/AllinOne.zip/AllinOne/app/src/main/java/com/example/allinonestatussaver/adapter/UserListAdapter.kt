package com.example.allinonestatussaver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.allinonestatussaver.databinding.ItemUserListBinding
import com.example.allinonestatussaver.interfaces.UserListInterface
import com.example.allinonestatussaver.model.story.TrayModel


class UserListAdapter(
    private val context: Context,
    private val trayModelArrayList: ArrayList<TrayModel?>?,
    private val userListInterface: UserListInterface
) : RecyclerView.Adapter<UserListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemUserListBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trayModel = trayModelArrayList?.get(position)

        if (trayModel != null) {
            holder.binding.realName.text = trayModel.users!!.full_name
        }
//        if (trayModel != null) {
//            Glide.with(context)
//                .load(trayModel.users?.profile_pic_url)
//                .thumbnail(0.2f)
//                .into(holder.binding.storyIcon)
//        }

        holder.binding.RLStoryLayout.setOnClickListener {
            userListInterface.userListClick(position, trayModelArrayList?.get(position))
        }
    }

    override fun getItemCount(): Int {
        return trayModelArrayList?.size !!
    }

    inner class ViewHolder(val binding: ItemUserListBinding) : RecyclerView.ViewHolder(binding.root)
}