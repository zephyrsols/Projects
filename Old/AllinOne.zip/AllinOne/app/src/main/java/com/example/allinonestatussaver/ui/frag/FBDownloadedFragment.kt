package com.example.allinonestatussaver.ui.frag

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.allinonestatussaver.adapter.FileListAdapter
import com.example.allinonestatussaver.databinding.FragmentHistoryBinding
import com.example.allinonestatussaver.interfaces.FileListClickInterface
import com.example.allinonestatussaver.ui.activity.FullViewActivity
import com.example.allinonestatussaver.ui.activity.GalleryActivity
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryFacebookShow
import java.io.File



class FBDownloadedFragment : Fragment(), FileListClickInterface {
    private lateinit var binding: FragmentHistoryBinding
    private lateinit var fileListAdapter: FileListAdapter
    private lateinit var fileArrayList: ArrayList<File>
    private lateinit var activity: GalleryActivity

    companion object {
        fun newInstance(param1: String): FBDownloadedFragment {
            val fragment = FBDownloadedFragment()
            val args = Bundle()
            args.putString("m", param1)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        activity = context as GalleryActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.getString("m")
    }

    override fun onResume() {
        super.onResume()
        activity = requireActivity() as GalleryActivity
        getAllFiles()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHistoryBinding.inflate(inflater, container, false)
        initViews()
        return binding.root
    }

    private fun initViews() {
        binding.swiperefresh.setOnRefreshListener {
            getAllFiles()
            binding.swiperefresh.isRefreshing = false
        }
    }

    private fun getAllFiles() {
        fileArrayList = ArrayList()
        val files = RootDirectoryFacebookShow.listFiles()
        files?.let {
            fileArrayList.addAll(it)
            fileListAdapter = FileListAdapter(activity, fileArrayList, this)
            binding.rvFileList.adapter = fileListAdapter
        }
    }

    override fun getPosition(position: Int, file: File?) {
        val inNext = Intent(activity, FullViewActivity::class.java)
        inNext.putExtra("ImageDataFile", fileArrayList)
        inNext.putExtra("Position", position)
        activity.startActivity(inNext)
    }
}