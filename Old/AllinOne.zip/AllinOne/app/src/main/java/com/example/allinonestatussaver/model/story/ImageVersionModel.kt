package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ImageVersionModel : Serializable {
    @SerializedName("candidates")
    var candidates: ArrayList<CandidatesModel>? = null
}