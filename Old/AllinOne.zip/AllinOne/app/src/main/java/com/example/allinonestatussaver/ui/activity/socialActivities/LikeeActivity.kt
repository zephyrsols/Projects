package com.example.allinonestatussaver.ui.activity.socialActivities

import android.app.ProgressDialog
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.api.CommonClassForAPI
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.util.AppLangSessionManager
import com.example.allinonestatussaver.util.Utils
import com.example.allinonestatussaver.util.Utils_status
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAd
import com.facebook.ads.InterstitialAdListener
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.MalformedURLException
import java.net.URL
import java.util.Locale
import java.util.regex.Pattern

class LikeeActivity : AppCompatActivity() {
    var binding: ActivityFacebookBinding? = null
    var activity: LikeeActivity? = null
    var commonClassForAPI: CommonClassForAPI? = null
    private var VideoUrl: String? = null
    private var clipBoard: ClipboardManager? = null
    var pattern = Pattern.compile("window\\.data \\s*=\\s*(\\{.+?\\});")
    var progressDialog: ProgressDialog? = null
    var appLangSessionManager: AppLangSessionManager? = null
    var downloadAsyncTask: AsyncTask<*, *, *>? = null
    private var interstitialAd: InterstitialAd? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layoutInflater: LayoutInflater? = null
        binding = ActivityFacebookBinding.inflate(
            layoutInflater!!
        )
        appLangSessionManager = AppLangSessionManager(activity)
        setLocale(appLangSessionManager!!.language)
        commonClassForAPI = CommonClassForAPI.getInstance(activity)
        Utils_status.createFileFolder()
        initViews()

//        AdsUtils.showFBBannerAdRect(activity,binding.bannerContainer);
//        FBInterstitialAdsINIT();
        initiliazeDialog()
    }

    fun initiliazeDialog() {
        progressDialog = ProgressDialog(activity)
        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        //progressDialog.setTitle("Please Wait.");
        progressDialog!!.setMessage(resources.getString(R.string.downloadin_video))
        progressDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.parseColor("#FFD4D9D0")))
        progressDialog!!.isIndeterminate = false
        progressDialog!!.setCancelable(false)
        progressDialog!!.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel") { dialog, which ->
            progressDialog!!.dismiss()
            if (downloadAsyncTask != null) {
                progressDialog!!.progress = 0
                downloadAsyncTask!!.cancel(true)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        activity = this
        assert(activity != null)
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        PasteText()
    }

    private fun initViews() {
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        binding!!.backArrow.setOnClickListener { onBackPressed() }
        //        binding.imInfo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//            }
//        });


//        Glide.with(activity)
//                .load(R.drawable.likee1)
//                .into(binding.layoutHowTo.imHowto1);
//
//        Glide.with(activity)
//                .load(R.drawable.likee2)
//                .into(binding.layoutHowTo.imHowto2);
//
//        Glide.with(activity)
//                .load(R.drawable.likee3)
//                .into(binding.layoutHowTo.imHowto3);
//
//        Glide.with(activity)
//                .load(R.drawable.likee4)
//                .into(binding.layoutHowTo.imHowto4);
//
//
//        binding.layoutHowTo.tvHowTo1.setText(getResources().getString(R.string.open_likee));
//        binding.layoutHowTo.tvHowTo3.setText(getResources().getString(R.string.copy_video_link_from_likee));
//
//        if (SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISSHOWHOWTOLIKEE)) {
//            SharePrefs.getInstance(activity).putBoolean(SharePrefs.ISSHOWHOWTOLIKEE,true);
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//        }else {
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.GONE);
//        }
//
//        binding.loginBtn1.setOnClickListener(v -> {
//            String LL = binding.etText.getText().toString();
//            if (LL.equals("")) {
//                Utils.setToast(activity, getResources().getString(R.string.enter_url));
//            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
//                Utils.setToast(activity, getResources().getString(R.string.enter_valid_url));
//            } else {
//                showInterstitial();
//                GetLikeeData();
//            }
//        });
        binding!!.paste.setOnClickListener { v: View? -> PasteText() }
        //        binding.LLOpenLikee.setOnClickListener(v -> {
//            Utils.OpenApp(activity,"video.like");
//        });
    }

    private fun GetLikeeData() {
        try {
            Utils_status.createFileFolder()
            val url = binding!!.etText.text.toString()
            if (url.contains("likee")) {
                Utils.showProgressDialog(activity)
                callGetLikeeData().execute(url)
            } else {
                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun PasteText() {
        try {
            binding!!.etText.setText("")
            val CopyIntent = intent.getStringExtra("CopyIntent")
            if (CopyIntent == "") {
                if (!clipBoard!!.hasPrimaryClip()) {
                } else if (!clipBoard!!.primaryClipDescription!!
                        .hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
                ) {
                    if (clipBoard!!.primaryClip!!.getItemAt(0).text.toString().contains("likee")) {
                        binding!!.etText.setText(clipBoard!!.primaryClip!!.getItemAt(0).text.toString())
                    }
                } else {
                    val item = clipBoard!!.primaryClip!!.getItemAt(0)
                    if (item.text.toString().contains("likee")) {
                        binding!!.etText.setText(item.text.toString())
                    }
                }
            } else {
                if (CopyIntent!!.contains("likee")) {
                    binding!!.etText.setText(CopyIntent)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    internal inner class callGetLikeeData : AsyncTask<String?, Void?, Document?>() {
        var likeeDoc: Document? = null
        override fun doInBackground(vararg p0: String?): Document? {
            TODO("Not yet implemented")
        }
//        override fun doInBackground(vararg p0: String?): Document? {
//            TODO("Not yet implemented")
//        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

//        protected  fun doInBackground(vararg urls: String): Document {
//            try {
//                likeeDoc = Jsoup.connect(urls[0]).get()
//            } catch (e: IOException) {
//                e.printStackTrace()
//                Log.d(ContentValues.TAG, "doInBackground: Error")
//            }
//            return likeeDoc!!
//        }

        protected fun onPostExecute(result: Document) {
            Utils.hideProgressDialog(activity)
            try {
                var JSONData = ""
                val matcher = pattern.matcher(result.toString())
                while (matcher.find()) {
                    JSONData = matcher.group().replaceFirst("window.data = ".toRegex(), "")
                        .replace(";", "")
                }
                val jsonObject = JSONObject(JSONData)
                VideoUrl = jsonObject.getString("video_url").replace("_4", "")
                //VideoUrl = VideoUrl.substring(VideoUrl.indexOf("http"),VideoUrl.indexOf("?"));
                Log.e("onPostExecute: ", VideoUrl!!)
                if (VideoUrl != "") {
                    try {
                        //startDownload(VideoUrl, RootDirectoryLikee, activity, getFilenameFromURL(VideoUrl));
                        progressDialog!!.show()
                        downloadAsyncTask = DownloadFileFromURL().execute(VideoUrl)
                        VideoUrl = ""
                        binding!!.etText.setText("")
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun getFilenameFromURL(url: String?): String {
        return try {
            File(URL(url).path).name + ""
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            System.currentTimeMillis().toString() + ".mp4"
        }
    }

    internal inner class DownloadFileFromURL : AsyncTask<String?, String?, String?>() {
        override fun doInBackground(vararg p0: String?): String? {
            TODO("Not yet implemented")
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected  fun dooInBackground(vararg f_url: String): String? {
            var count: Int
            try {
                val url = URL(f_url[0])
                val conection = url.openConnection()
                conection.connect()
                val lenghtOfFile = conection.contentLength
                val input: InputStream = BufferedInputStream(url.openStream(), 8192)
                val output: OutputStream = FileOutputStream(
                    Utils_status.RootDirectoryLikeeShow.toString() + "/" + getFilenameFromURL(
                        VideoUrl
                    )
                )
                val data = ByteArray(1024)
                var total: Long = 0
                while (input.read(data).also { count = it } != -1) {
                    total += count.toLong()
                    publishProgress("" + (total * 100 / lenghtOfFile).toInt())
                    output.write(data, 0, count)
                }
                output.flush()
                output.close()
                input.close()
            } catch (e: Exception) {
                Log.e("Error: ", e.message!!)
            }

            return null
        }

        protected  fun onProgressUpdate(vararg progress: String) {
            progressDialog!!.progress = progress[0].toInt()
        }

        protected  fun onPostExecute(file_url: String) {
            progressDialog!!.dismiss()
            progressDialog!!.progress = 0
            Utils.setToast(activity, resources.getString(R.string.download_complete))
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(
                            File(
                                Utils_status.RootDirectoryLikeeShow.toString() + "/" + getFilenameFromURL(
                                    VideoUrl
                                )
                            ).absolutePath
                        ),
                        null
                    ) { path, uri -> }
                } else {
                    activity!!.sendBroadcast(
                        Intent(
                            "android.intent.action.MEDIA_MOUNTED",
                            Uri.fromFile(
                                File(
                                    Utils_status.RootDirectoryLikeeShow.toString() + "/" + getFilenameFromURL(
                                        VideoUrl
                                    )
                                )
                            )
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun onCancelled() {
            super.onCancelled()
            progressDialog!!.progress = 0
            Log.d(ContentValues.TAG, "onCancelled: AysncTask")
        }
    }

    fun setLocale(lang: String?) {
        val myLocale = Locale(lang)
        val res = resources
        val dm = res.displayMetrics
        val conf = res.configuration
        conf.locale = myLocale
        res.updateConfiguration(conf, dm)
    }

    //FB INTERSTITIAL ADS : STARTED
    fun FBInterstitialAdsINIT() {
        interstitialAd =
            InterstitialAd(this, resources.getString(R.string.fb_placement_interstitial_id))
        // Set listeners for the Interstitial Ad
        interstitialAd!!.setAdListener(object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {
                // Interstitial ad displayed callback
                Log.e(ContentValues.TAG, "Interstitial ad displayed.")
            }

            override fun onInterstitialDismissed(ad: Ad) {
                // Interstitial dismissed callback
                Log.e(ContentValues.TAG, "Interstitial ad dismissed.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Ad error callback
            }

            override fun onAdLoaded(ad: Ad) {
                // Interstitial ad is loaded and ready to be displayed
                Log.d(ContentValues.TAG, "Interstitial ad is loaded and ready to be displayed!")
                // Show the ad
            }

            override fun onAdClicked(ad: Ad) {
                // Ad clicked callback
                Log.d(ContentValues.TAG, "Interstitial ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Ad impression logged callback
                Log.d(ContentValues.TAG, "Interstitial ad impression logged!")
            }
        })

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown
        interstitialAd!!.loadAd()
    }

    private fun showInterstitial() {
        if (interstitialAd != null && interstitialAd!!.isAdLoaded) {
            interstitialAd!!.show()
        }
    } //FB INTERSTITIAL ADS : END
}