package com.example.allinonestatussaver.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class TwitterResponse : Serializable {
    @SerializedName("videos")
    var videos: ArrayList<TwitterResponseModel>? = null
}