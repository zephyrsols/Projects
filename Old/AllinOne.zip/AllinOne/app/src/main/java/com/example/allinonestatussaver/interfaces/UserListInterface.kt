package com.example.allinonestatussaver.interfaces

import com.example.allinonestatussaver.model.story.TrayModel
import com.example.allinonestatussaver.ui.activity.socialActivities.InstagramActivity
import com.facebook.ads.InterstitialAd

interface UserListInterface {
    fun userListClick(position: Int, trayModel: TrayModel?)
    abstract fun InterstitialAd(instagramActivity: InstagramActivity): InterstitialAd
}