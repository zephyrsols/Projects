package com.example.allinonestatussaver.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class TiktokModel : Serializable {
    @SerializedName("status")
    var status: String? = null

    @SerializedName("message")
    var message: String? = null

    @SerializedName("responsecode")
    var responsecode: String? = null

    @SerializedName("description")
    var description: String? = null

    @SerializedName("data")
    var data: TiktokDataModel? = null
}