package com.example.allinonestatussaver.ui.activity

import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater

import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
import androidx.viewpager.widget.ViewPager
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivityGalleryBinding
import com.example.allinonestatussaver.ui.frag.FBDownloadedFragment
import com.example.allinonestatussaver.ui.frag.InstaDownloadedFragment
import com.example.allinonestatussaver.ui.frag.LikeeDownloadedFragment
import com.example.allinonestatussaver.ui.frag.RoposoDownloadedFragment
import com.example.allinonestatussaver.ui.frag.SharechatDownloadedFragment
import com.example.allinonestatussaver.ui.frag.SnackVideoDownloadedFragment
import com.example.allinonestatussaver.ui.frag.TikTokDownloadedFragment
import com.example.allinonestatussaver.ui.frag.TwitterDownloadedFragment
import com.example.allinonestatussaver.ui.frag.WhatsAppDowndlededFragment
import com.example.allinonestatussaver.util.Utils_status.createFileFolder
import java.util.*

class GalleryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initViews()
    }

    private fun initViews() {
        setupViewPager(binding.viewpager)
        binding.tabs.setupWithViewPager(binding.viewpager)
        binding.backArrow.setOnClickListener {
            onBackPressed()
        }

        for (i in 0 until binding.tabs.tabCount) {
            val tv = LayoutInflater.from(this).inflate(R.layout.custom_tab, null) as TextView
            binding.tabs.getTabAt(i)?.customView = tv
        }

        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {}

            override fun onPageScrollStateChanged(state: Int) {}
        })
        createFileFolder()
    }

    private fun setupViewPager(viewPager: ViewPager) {
        val adapter = ViewPagerAdapter(supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
        adapter.addFragment(SnackVideoDownloadedFragment(), "Snack Video")
        adapter.addFragment(SharechatDownloadedFragment(), "Sharechat")
        adapter.addFragment(RoposoDownloadedFragment(), "Roposo")
        adapter.addFragment(InstaDownloadedFragment(), "Instagram")
        adapter.addFragment(WhatsAppDowndlededFragment(), "Whatsapp")
        adapter.addFragment(TikTokDownloadedFragment(), "TikTok")
        adapter.addFragment(FBDownloadedFragment(), "Facebook")
        adapter.addFragment(TwitterDownloadedFragment(), "Twitter")
        adapter.addFragment(LikeeDownloadedFragment(), "Likee")

        viewPager.adapter = adapter
        viewPager.offscreenPageLimit = 4
    }

    private inner class ViewPagerAdapter(fm: FragmentManager, behavior: Int) :
        FragmentPagerAdapter(fm, behavior) {

        private val mFragmentList = mutableListOf<Fragment>()
        private val mFragmentTitleList = mutableListOf<String>()

        override fun getItem(position: Int): Fragment = mFragmentList[position]

        override fun getCount(): Int = mFragmentList.size

        fun addFragment(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence? = mFragmentTitleList[position]
    }

    private fun setLocale(lang: String) {
        val myLocale = Locale(lang)
        val res: Resources = resources
        val dm: DisplayMetrics = res.displayMetrics
        val conf: Configuration = res.configuration
        conf.locale = myLocale
        res.updateConfiguration(conf, dm)
    }
}