package com.example.allinonestatussaver.ui.activity.socialActivities

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentValues.TAG
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.api.CommonClassForAPI
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.ui.MainActivity
import com.example.allinonestatussaver.util.Utils_status
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryFacebook
import com.example.allinonestatussaver.util.Utils_status.createFileFolder
import com.example.allinonestatussaver.util.Utils_status.startDownload
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.File
import java.io.IOException
import java.net.MalformedURLException
import java.net.URL

class FacebookActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFacebookBinding
    private lateinit var commonClassForAPI: CommonClassForAPI
    private var videoUrl: String = ""
    private lateinit var clipBoard: ClipboardManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFacebookBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val name = intent.getStringExtra("title")
        binding?.mainTitle?.setText(name)


        commonClassForAPI = CommonClassForAPI.getInstance(this)
        createFileFolder()
        initViews()


        binding.homeIcon.setOnClickListener { (callHomeActivity()) }
        binding.tabs.setOnClickListener { (callWhatsappActivity()) }
        binding.paste.setOnClickListener { (PasteText()) }

        }

    fun callHomeActivity() {
        val i = Intent(this, MainActivity::class.java)


        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(i)
        finish()
    }


    fun callWhatsappActivity() {
        val i = Intent(this, WhatsappActivity::class.java)

        startActivity(i)


    }


    override fun onResume() {
        super.onResume()
        clipBoard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        PasteText()


    }

    private fun initViews() {
        clipBoard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        // Rest of your view initialization code...

        binding.backArrow.setOnClickListener { onBackPressed() }
//        binding.imInfo.setOnClickListener { binding.layoutHowTo.LLHowToLayout.visibility = View.VISIBLE }

        binding.download.setOnClickListener {
            val LL = binding.etText.text.toString()
            when {
                LL.isEmpty() -> Utils_status.setToast(this, getString(R.string.enter_url))
                !Patterns.WEB_URL.matcher(LL).matches() -> Utils_status.setToast(
                    this,
                    getString(R.string.enter_valid_url)
                )

                else -> {
                    GetFacebookData()
                    // showInterstitial()
                }
            }
        }
    }

    private fun GetFacebookData() {
        try {
            createFileFolder()
            val url = URL(binding.etText.text.toString())
            val host = url.host
            if (host.contains("fb")) {
                Utils_status.showProgressDialog(this@FacebookActivity)
                callGetFacebookData().execute(binding.etText.text.toString())
            } else {
                Utils_status.setToast(
                    this@FacebookActivity,
                    resources.getString(R.string.enter_valid_url)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun PasteText() {
        try {
            binding.etText.setText("")
            val CopyIntent = intent.getStringExtra("CopyIntent")
            if (CopyIntent == "") {
                if (!clipBoard.hasPrimaryClip()) {
                } else if (!clipBoard.primaryClipDescription!!.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                    if (clipBoard.primaryClip!!.getItemAt(0).text.toString()
                            .contains("fb")
                    ) {
                        binding.etText.setText(clipBoard.primaryClip!!.getItemAt(0).text.toString())
                    }
                } else {
                    val item = clipBoard.primaryClip!!.getItemAt(0)
                    if (item.text.toString().contains("fb")) {
                        binding.etText.setText(item.text.toString())
                    }
                }
            } else {
                if (CopyIntent!!.contains("fb")) {
                    binding.etText.setText(CopyIntent)
                }
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("StaticFieldLeak")
    inner class callGetFacebookData : AsyncTask<String, Void, Document>() {
        lateinit var facebookDoc: Document

        override fun doInBackground(vararg urls: String?): Document? {
            try {
                facebookDoc = Jsoup.connect(urls[0]).get()
            } catch (e: IOException) {
                e.printStackTrace()
                Log.d(TAG, "doInBackground: Error")
            }
            return facebookDoc
        }

        override fun onPostExecute(result: Document?) {
            Utils_status.hideProgressDialog(this@FacebookActivity)
            try {
                startDownload(
                    videoUrl,
                    RootDirectoryFacebook,
                    this@FacebookActivity,
                    getFilenameFromURL(videoUrl)
                )
                videoUrl = ""
                binding.etText.text = null
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("DownloadError", "Error downloading video: ${e.message}")
            }
            videoUrl = result?.select("meta[property=\"og:video\"]")?.last()?.attr("content") ?: ""

//            try {
//                videoUrl = result?.select("meta[property=\"og:video\"]")?.last()?.attr("content") ?: ""
//                if (videoUrl.isNotEmpty()) {
//                    try {
//                        startDownload(videoUrl, RootDirectoryFacebook, this@FacebookActivity, getFilenameFromURL(videoUrl))
//                        videoUrl = ""
//                        binding.etText.text = null
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                } else {
//                    // Handle case when videoUrl is empty
//                }
//            } catch (e: NullPointerException) {
//                e.printStackTrace()
//            }
//        }
        }

        private fun getFilenameFromURL(url: String): String {
            return try {
                File(URL(url).path).name + ".mp4"
            } catch (e: MalformedURLException) {
                e.printStackTrace()
                "${System.currentTimeMillis()}.mp4"
            }
        }

    }
}