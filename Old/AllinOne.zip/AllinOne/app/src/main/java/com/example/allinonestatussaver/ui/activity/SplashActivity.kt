package com.example.allinonestatussaver.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.databinding.ActivitySplashBinding
import com.example.allinonestatussaver.extensionFun.baseConfig
import com.example.allinonestatussaver.sharedPreferencesLang.MySharePreferences
import com.example.allinonestatussaver.ui.MainActivity
import com.example.allinonestatussaver.ui.onBoarding.IntroSliderActivity
import com.example.allinonestatussaver.util.setCurrentLocale

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    var started = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        /*  if (!baseConfig.appStarted) {
              if (isNetworkAvailable()) {
                  loadHighOrLowNativeAd(
                      this,
                      getString(R.string.admob_native_lang_high),
                      getString(R.string.admob_native_lang_low)
                  ) { nativeAd, adType ->
                      Log.d("danishTest1", "loadHighOrLowNativeAd: ad:$nativeAd typr:$adType")
                      if (nativeAd != null) {
                          PhoneLookupAppClass.instance.nativeAdLang.postValue(nativeAd)
                      } else {
                          PhoneLookupAppClass.instance.nativeAdLang.postValue(null)
                      }
                  }
              } else {
                  PhoneLookupAppClass.instance.nativeAdLang.postValue(null)
              }

          }
          else if (!baseConfig.isAppIntroComplete) {
              loadHighOrLowNativeAd(
                  this,
                  getString(R.string.admob_native_boarding),
                  getString(R.string.admob_native_boarding)
              ) { nativeAd, adType ->
                  if (nativeAd != null) {
                      PhoneLookupAppClass.instance.nativeAdBoarding.value = nativeAd
                  } else {
                      PhoneLookupAppClass.instance.nativeAdBoarding.value = null
                  }
              }
          }
          else {
              loadHighOrLowNativeAd(
                  this,
                  getString(R.string.admob_native_main_high),
                  getString(R.string.admob_native_main_low)
              ) { nativeAd, adType ->
                  Log.d("danishtest", "loadHighOrLowNativeAd: ad:$nativeAd typr:$adType")
                  if (nativeAd != null) {
                      PhoneLookupAppClass.instance.nativeAdMain.postValue(nativeAd)
                  } else {
                      PhoneLookupAppClass.instance.nativeAdMain.postValue(null)
                  }
              }
          }

          loadPriorityAdmobInterstitial(
              getString(R.string.admob_splash_interistitial_high),
              getString(R.string.admob_splash_interistitial_low)
          ) {
              interstitialAdPriority = it
          }
  */

        setCurrentLocale(baseConfig.appLanguage.toString())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        } else {
            val w: Window = this.window
            w.setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            )
        }

        val mySharePreferences = MySharePreferences(this)
        started = mySharePreferences.appStarted

        splashEnd()

    }

    private fun splashEnd() {

        Handler(Looper.getMainLooper()).postDelayed({

            if (!baseConfig.appStarted) {
                // The user has seen the Onboard
                startActivity(Intent(this@SplashActivity, LanguageActivity::class.java))
                finish()
            } else if (!baseConfig.isAppIntroComplete) {
                startActivity(
                    Intent(
                        this@SplashActivity,
                        IntroSliderActivity::class.java
                    ).putExtra("isComingFromSplash", true)
                )
                finish()
            } else {
//                isShowAD=true
                startActivity(
                    Intent(
                        this@SplashActivity,
                        MainActivity::class.java
                    )
                )
                finish()
            }
        }, 5000)
    }

}