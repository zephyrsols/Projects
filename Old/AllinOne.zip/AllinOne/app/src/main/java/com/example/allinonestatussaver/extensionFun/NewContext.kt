package com.example.allinonestatussaver.extensionFun

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.Context.CLIPBOARD_SERVICE
import android.content.Context.LOCATION_SERVICE
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.drawable.Drawable
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Uri
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.allinonestatussaver.BaseConfig
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.helper.PERMISSION_ACCESS_FINE_LOCATION
import com.example.allinonestatussaver.helper.PERMISSION_CALL_PHONE
import com.example.allinonestatussaver.helper.PERMISSION_GET_ACCOUNTS
import com.example.allinonestatussaver.helper.PERMISSION_READ_CALENDAR
import com.example.allinonestatussaver.helper.PERMISSION_READ_CALL_LOG
import com.example.allinonestatussaver.helper.PERMISSION_READ_CONTACTS
import com.example.allinonestatussaver.helper.PERMISSION_READ_PHONE_STATE
import com.example.allinonestatussaver.helper.PERMISSION_READ_STORAGE
import com.example.allinonestatussaver.helper.PERMISSION_WRITE_CALENDAR
import com.example.allinonestatussaver.helper.PERMISSION_WRITE_CALL_LOG
import com.example.allinonestatussaver.helper.PERMISSION_WRITE_CONTACTS
import com.example.allinonestatussaver.helper.PERMISSION_WRITE_STORAGE
import com.example.allinonestatussaver.helper.PREFS_KEY
import java.util.*


//SharePref
fun Context.getSharedPrefs(): SharedPreferences =
    getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)

val Context.baseConfig: BaseConfig get() = BaseConfig.newInstance(this)

fun Context.launchActivityIntent(intent: Intent) {
    try {
        Log.d("TAG", "launchActivityIntent: $intent")
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        toast(R.string.no_app_found)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

fun Context.toast(str: Int) {
    Toast.makeText(this, str, Toast.LENGTH_SHORT).show()
}


fun Context.queryCursor(
    uri: Uri,
    projection: Array<String>,
    selection: String? = null,
    selectionArgs: Array<String>? = null,
    sortOrder: String? = null,
    showErrors: Boolean = false,
    callback: (cursor: Cursor) -> Unit
) {
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        cursor?.use {
            if (cursor.moveToFirst()) {
                do {
                    callback(cursor)
                } while (cursor.moveToNext())
            }
        }
    } catch (e: Exception) {
        if (showErrors) {
            showErrorToast(e)
        }
    }
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception, length)
}

fun Context.hasPermission(permId: Int) = ContextCompat.checkSelfPermission(
    this, getPermissionString(permId)
) == PackageManager.PERMISSION_GRANTED

fun getPermissionString(id: Int) = when (id) {
    PERMISSION_READ_STORAGE -> Manifest.permission.READ_EXTERNAL_STORAGE
    PERMISSION_WRITE_STORAGE -> Manifest.permission.WRITE_EXTERNAL_STORAGE
    PERMISSION_READ_CONTACTS -> Manifest.permission.READ_CONTACTS
    PERMISSION_WRITE_CONTACTS -> Manifest.permission.WRITE_CONTACTS
    PERMISSION_READ_CALENDAR -> Manifest.permission.READ_CALENDAR
    PERMISSION_WRITE_CALENDAR -> Manifest.permission.WRITE_CALENDAR
    PERMISSION_CALL_PHONE -> Manifest.permission.CALL_PHONE
    PERMISSION_READ_CALL_LOG -> Manifest.permission.READ_CALL_LOG
    PERMISSION_WRITE_CALL_LOG -> Manifest.permission.WRITE_CALL_LOG
    PERMISSION_GET_ACCOUNTS -> Manifest.permission.GET_ACCOUNTS
    PERMISSION_READ_PHONE_STATE -> Manifest.permission.READ_PHONE_STATE
    PERMISSION_ACCESS_FINE_LOCATION -> Manifest.permission.ACCESS_FINE_LOCATION
    else -> ""
}

@SuppressLint("UseCompatLoadingForDrawables")
fun Context.getImage(name: String?): Drawable? {
    return this.resources.getDrawable(
        this.resources.getIdentifier(
            name, "drawable", this.packageName
        )
    )
}

fun Context.copyText(str: String) {
    val clipboard: ClipboardManager? = this.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager?
    val clip = ClipData.newPlainText("label", str)
    clipboard?.setPrimaryClip(clip)
}

fun Context.getWindowWidth(percent: Float = 1.0f): Int {
    val displayMetrics = resources.displayMetrics
    return (displayMetrics.widthPixels * percent).toInt()
}


fun View.hideKeyboard(context: Context) {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}


fun Context.isNetworkAvailable(): Boolean {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
    val activeNetworkInfo = connectivityManager?.activeNetworkInfo
    return activeNetworkInfo != null && activeNetworkInfo.isConnected
}

fun Activity.gpsStatusCheck(callBack: ((Boolean) -> Unit)?) {
    var status = true
    val manager = getSystemService(LOCATION_SERVICE) as LocationManager?
    if (!manager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
        buildAlertMessageNoGps()
        status = false
    }
    callBack?.invoke(status)
}

fun Activity.buildAlertMessageNoGps() {
    val builder: AlertDialog.Builder = AlertDialog.Builder(this)
    builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
        .setCancelable(false).setPositiveButton("Yes",
            DialogInterface.OnClickListener { dialog, id -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) })
        .setNegativeButton("No", DialogInterface.OnClickListener { dialog, id -> dialog.cancel() })
    val alert: AlertDialog = builder.create()
    alert.show()
}

val Context.hasNotificationListenerGranted: Boolean
    get() = run {
        val contentResolver = this.contentResolver
        val enabledNotificationListeners =
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val packageName = this.packageName
        return !(enabledNotificationListeners == null || !enabledNotificationListeners.contains(
            packageName
        ))
    }
