package com.example.allinonestatussaver.ui

import android.Manifest.permission.READ_EXTERNAL_STORAGE
import android.Manifest.permission.WRITE_EXTERNAL_STORAGE
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivityMainBinding
import com.example.allinonestatussaver.ui.activity.socialActivities.FacebookActivity
import com.example.allinonestatussaver.ui.activity.GalleryActivity
import com.example.allinonestatussaver.ui.activity.SettingActivity
import com.example.allinonestatussaver.ui.activity.socialActivities.InstagramActivity
import com.example.allinonestatussaver.ui.activity.socialActivities.TikTokActivity
import com.example.allinonestatussaver.ui.activity.socialActivities.WhatsappActivity
import com.example.allinonestatussaver.util.Utils_status
import com.example.allinonestatussaver.util.Utils_status.createFileFolder

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding
    private var doubleBackToExitPressedOnce = false
    private lateinit var clipBoard: ClipboardManager
    private val permissions = arrayOf(
        WRITE_EXTERNAL_STORAGE,
        READ_EXTERNAL_STORAGE
    )
    private var copyKey = ""
    private var copyValue = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        initViews()
    }


    override fun onResume() {
        super.onResume()
        clipBoard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
    }

    private fun initViews() {
        clipBoard = this.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        if (this.intent.extras != null) {
            for (key in this.intent.extras!!.keySet()) {
                copyKey = key
                val value = this.intent.extras!!.getString(copyKey)
                if (copyKey == "android.intent.extra.TEXT") {
                    copyValue = this.intent.extras!!.getString(copyKey).toString()
                    if (value != null) {
                        callText(value)
                    }
                } else {
                    copyValue = ""
                    if (value != null) {
                        callText(value)
                    }
                }
            }
        }
        clipBoard.addPrimaryClipChangedListener {
            try {
                clipBoard.primaryClip?.getItemAt(0)?.text?.let { showNotification(it.toString()) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (Build.VERSION.SDK_INT >= 23) {
            checkPermissions(0)
        }

        binding.likee.setOnClickListener(this)
        binding.insta.setOnClickListener(this)
        binding.whatsapp.setOnClickListener(this)
        binding.tiktok.setOnClickListener(this)
        binding.fb.setOnClickListener(this)
        binding.twitter.setOnClickListener(this)
        binding.gallery.setOnClickListener(this)
        binding.whatsapptab.setOnClickListener(this)
        binding.settingicon.setOnClickListener(this)
//        binding.rvRateApp.setOnClickListener(this)
//        binding.rvMoreApp.setOnClickListener(this)
//        binding.rvSnack.setOnClickListener(this)
        binding.snapchat.setOnClickListener(this)
        binding.roposo.setOnClickListener(this)


        createFileFolder()
    }

    private fun callText(copiedText: String) {
        try {
            when {
                copiedText.contains("likee") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(100)
                    } else {
                        callLikeeActivity()
                    }
                }
                copiedText.contains("instagram.com") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(101)
                    } else {
                        callInstaActivity()
                    }
                }
                copiedText.contains("facebook.com") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(104)
                    } else {
                        callFacebookActivity()
                    }
                }
                copiedText.contains("tiktok.com") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(103)
                    } else {
                        callTikTokActivity()
                    }
                }
                copiedText.contains("twitter.com") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(106)
                    } else {
                        callTwitterActivity()
                    }
                }
                copiedText.contains("sharechat") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(107)
                    } else {
                        callShareChatActivity()
                    }
                }
                copiedText.contains("roposo") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(108)
                    } else {
                        callRoposoActivity()
                    }
                }
                copiedText.contains("snackvideo") || copiedText.contains("sck.io") -> {
                    if (Build.VERSION.SDK_INT >= 23) {
                        checkPermissions(109)
                    } else {
                        callSnackVideoActivity()
                    }
                }



            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onClick(v: View) {
        val i: Intent?
        when (v.id) {
            R.id.likee -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(100)
                } else {
                    callLikeeActivity()
                }
            }
            R.id.insta -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(101)
                } else {
                    callInstaActivity()
                }
            }
            R.id.whatsapp -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(102)
                } else {
                    callWhatsappActivity()
                }
            }

            R.id.whatsapptab -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(102)
                } else {
                    callWhatsappActivity()
                }
            }

            R.id.tiktok -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(103)
                } else {
                    callTikTokActivity()
                }
            }
            R.id.fb -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(104)
                } else {
                    callFacebookActivity()
                }
            }
            R.id.gallery -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(105)
                } else {
                    callGalleryActivity()
                }
            }
            R.id.twitter -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(106)
                } else {
                    callTwitterActivity()
                }
            }
           /* R.id.rvAbout -> {
                val i = Intent(this, AboutUsActivity::class.java)
                startActivity(i)
            }
            R.id.rvShareApp -> Utils.ShareApp(this)
            R.id.rvRateApp -> Utils.RateApp(this)
            R.id.rvMoreApp -> Utils.MoreApp(this)
            R.id.rvShareChat -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(107)
                } else {
                    callShareChatActivity()
                }
            }*/
            R.id.roposo -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(108)
                } else {
                    callRoposoActivity()
                }
            }
            R.id.snapchat -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(109)
                } else {
                    callSnackVideoActivity()
                }
            }

            R.id.settingicon -> {

                callSettingActivity()

            }

        }
    }

    private fun callLikeeActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title", "Likee")
        startActivity(i)


    }


    private fun callInstaActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","Instagram")
        startActivity(i)


    }

    private fun callWhatsappActivity() {
        val i = Intent(this, WhatsappActivity::class.java)
        startActivity(i)



    }

    private fun callTikTokActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","TikTok")
        startActivity(i)



    }

    fun callFacebookActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","FaceBook")
        startActivity(i)




    }

    private fun callTwitterActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","Twitter")
        startActivity(i)


    }

    private fun callGalleryActivity() {
        val i = Intent(this, GalleryActivity::class.java)

        startActivity(i)


    }

    private fun callRoposoActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","Ropsoo")
        startActivity(i)


    }

    private fun callShareChatActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        startActivity(i)



    }

    private fun callSnackVideoActivity() {
        val i = Intent(this, FacebookActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        i.putExtra("title","SnapChat")
        startActivity(i)


    }
    private fun callSettingActivity() {
        val i = Intent(this, SettingActivity::class.java)
        i.putExtra("CopyIntent", copyValue)
        startActivity(i)


    }




    private fun showNotification(text: String) {
        if (text.contains("instagram.com") || text.contains("facebook.com") || text.contains("tiktok.com")
            || text.contains("twitter.com") || text.contains("likee")
            || text.contains("sharechat") || text.contains("roposo") || text.contains("snackvideo") || text.contains("sck.io")) {

            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.putExtra("Notification", text)
            val pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)
            val notificationManager = this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val mChannel = NotificationChannel(
                    this.resources.getString(R.string.app_name),
                    this.resources.getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_HIGH
                )
                mChannel.enableLights(true)
                mChannel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                notificationManager.createNotificationChannel(mChannel)
            }

            val notificationBuilder = NotificationCompat.Builder(this, this.resources.getString(R.string.app_name))
                .setAutoCancel(true)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setColor(ContextCompat.getColor(this, R.color.text_color))
                .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.mipmap.ic_launcher_round))
                .setDefaults(Notification.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentTitle("Copied text")
                .setContentText(text)
                .setChannelId(this.resources.getString(R.string.app_name))
                .setFullScreenIntent(pendingIntent, true)

            notificationManager.notify(1, notificationBuilder.build())
        }
    }

    private fun checkPermissions(type: Int): Boolean {
        val listPermissionsNeeded = mutableListOf<String>()
        for (p in permissions) {
            val result = ContextCompat.checkSelfPermission(this, p)
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p)
            }
        }
        if (listPermissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this as Activity,
                listPermissionsNeeded.toTypedArray(),
                type
            )
            return false
        } else {
            when (type) {
                100 -> callLikeeActivity()
                101 -> callInstaActivity()
                102 -> callWhatsappActivity()
                103 -> callTikTokActivity()
                104 -> callFacebookActivity()
                105 -> callGalleryActivity()
                106 -> callTwitterActivity()
                107 -> callShareChatActivity()
                108 -> callRoposoActivity()
                109 -> callSnackVideoActivity()
            }
        }
        return true
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            100 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callLikeeActivity()
                }
            }
            101 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callInstaActivity()
                }
            }
            102 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callWhatsappActivity()
                }
            }
            103 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callTikTokActivity()
                }
            }
            104 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callFacebookActivity()
                }
            }
            105 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callGalleryActivity()
                }
            }
            106 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callTwitterActivity()
                }
            }
            107 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callShareChatActivity()
                }
            }
            108 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callRoposoActivity()
                }
            }
            109 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callSnackVideoActivity()
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (doubleBackToExitPressedOnce) {
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }
        doubleBackToExitPressedOnce = true
        Utils_status.setToast(this, resources.getString(R.string.pls_bck_again))
        Handler().postDelayed({
            doubleBackToExitPressedOnce = false
        }, 2000)
    }

  }

//    fun callSettingActivity(view: View) {}
//
//}


/*
class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        handleClicks()
    }
    private fun handleClicks(){
        binding.settingIcon.setOnClickListener { // Handle the click event
            startActivity(Intent(this, SettingActivity::class.java))
        }
        binding.gallery.setOnClickListener { // Handle the click event
            startActivity(Intent(this, GalleryActivity::class.java))
        }
        binding.fb.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.insta.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.whatsapp.setOnClickListener { // Handle the click event
            startActivity(Intent(this, WhatsappActivity::class.java))
        }

        binding.tiktok.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.twitter.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.roposo.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.likee.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }
        binding.snapchat.setOnClickListener { // Handle the click event
            startActivity(Intent(this, FacebookActivity::class.java))
        }

    }
}*/
