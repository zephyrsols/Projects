package com.example.allinonestatussaver.ui.activity.socialActivities

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
import androidx.viewpager.widget.ViewPager
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivityWhatsappBinding
import com.example.allinonestatussaver.ui.MainActivity
import com.example.allinonestatussaver.ui.frag.WhatsappImageFragment
import com.example.allinonestatussaver.ui.frag.WhatsappVideoFragment
import com.example.allinonestatussaver.util.Utils_status.createFileFolder

class WhatsappActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWhatsappBinding
    private lateinit var activity: WhatsappActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWhatsappBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this
        createFileFolder()
        initViews()

        binding.home.setOnClickListener{(callHomeActivity())}

    }

    fun callHomeActivity() {
        val i = Intent(this, MainActivity::class.java)

        startActivity(i)

    }

    override fun onResume() {
        super.onResume()
        activity = this
    }

    private fun initViews() {
        setupViewPager(binding.viewpager)
        binding.tabs.setupWithViewPager(binding.viewpager)
        binding.backArrow.setOnClickListener { onBackPressed() }

        for (i in 0 until binding.tabs.tabCount) {
            val tv = LayoutInflater.from(activity).inflate(R.layout.custom_tab, null) as TextView
            binding.tabs.getTabAt(i)?.customView = tv
        }

       /* binding.LLOpenWhatsapp.setOnClickListener {
            Utils_status.OpenApp(activity, "com.whatsapp")
        }*/
    }

    private fun setupViewPager(viewPager: ViewPager) {
        val adapter = ViewPagerAdapter(supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
        adapter.addFragment(WhatsappImageFragment(), getString(R.string.images))
        adapter.addFragment(WhatsappVideoFragment(), getString(R.string.videos))
        viewPager.adapter = adapter
        viewPager.offscreenPageLimit = 1
    }

    internal inner class ViewPagerAdapter(fm: FragmentManager, behavior: Int) : FragmentPagerAdapter(fm, behavior) {
        private val mFragmentList = mutableListOf<Fragment>()
        private val mFragmentTitleList = mutableListOf<String>()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFragment(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return mFragmentTitleList[position]
        }
    }

}