package com.example.allinonestatussaver.api

import com.example.allinonestatussaver.model.TiktokModel
import com.example.allinonestatussaver.model.TwitterResponse
import com.example.allinonestatussaver.model.story.FullDetailModel
import com.example.allinonestatussaver.model.story.StoryModel
import com.google.gson.JsonObject
import io.reactivex.Observable
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface APIServices {
    @GET
    fun callResult(
        @Url Value: String?,
        @Header("Cookie") cookie: String?,
        @Header("User-Agent") userAgent: String?
    ): Observable<JsonObject?>?

    @FormUrlEncoded
    @POST
    fun callTwitter(@Url Url: String?, @Field("id") id: String?): Observable<TwitterResponse?>?

    @POST
    fun getTiktokData(
        @Url Url: String?,
        @Body hashMap: HashMap<String?, String?>?
    ): Observable<TiktokModel?>?

    @GET
    fun getStoriesApi(
        @Url Value: String?,
        @Header("Cookie") cookie: String?,
        @Header("User-Agent") userAgent: String?
    ): Observable<StoryModel?>?

    @GET
    fun getFullDetailInfoApi(
        @Url Value: String?,
        @Header("Cookie") cookie: String?,
        @Header("User-Agent") userAgent: String?
    ): Observable<FullDetailModel?>?

    @FormUrlEncoded
    @POST
    fun callSnackVideo(
        @Url Url: String?,
        @Field("shortKey") shortKey: String?,
        @Field("os") os: String?,
        @Field("sig") sig: String?,
        @Field("client_key") client_key: String?
    ): Observable<JsonObject?>?
}