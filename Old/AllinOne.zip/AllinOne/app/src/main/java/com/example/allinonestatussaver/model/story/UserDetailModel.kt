package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class UserDetailModel : Serializable {
    @SerializedName("user")
    var user: User? = null
}