package com.example.allinonestatussaver.model

import android.net.Uri

class WhatsappStatusModel(var name: String, var uri: Uri, var path: String, var filename: String)