//package com.example.allinonestatussaver.interfaces;
//
//import com.google.android.gms.ads.initialization.InitializationStatus;
//
//public interface OnInitializationCompleteListener {
//    void onInitializationComplete(InitializationStatus var1);
//
//}
