package com.example.allinonestatussaver.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.viewpager.widget.ViewPager
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.adapter.ShowImagesAdapter
import com.example.allinonestatussaver.databinding.ActivityFullViewBinding
import com.example.allinonestatussaver.databinding.ActivityGalleryBinding
import com.example.allinonestatussaver.extensionFun.toast
import com.example.allinonestatussaver.util.Utils_status.shareImage
import com.example.allinonestatussaver.util.Utils_status.shareImageVideoOnWhatsapp
import com.example.allinonestatussaver.util.Utils_status.shareVideo
import java.io.File

class FullViewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFullViewBinding
    private lateinit var fileArrayList: ArrayList<File>
    private var Position = 0
    private lateinit var showImagesAdapter: ShowImagesAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val extras = intent.extras
        if (extras != null) {
            fileArrayList = intent.getSerializableExtra("ImageDataFile") as ArrayList<File>
            Position = intent.getIntExtra("Position", 0)
        }
        initViews()
    }

    private fun initViews() {
        showImagesAdapter = ShowImagesAdapter(this, fileArrayList, this)
        binding.vpView.adapter = showImagesAdapter
        binding.vpView.currentItem = Position

        binding.vpView.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageSelected(arg0: Int) {
                Position = arg0
                Log.d("Current position==", "$Position")
            }

            override fun onPageScrolled(arg0: Int, arg1: Float, arg2: Int) {}

            override fun onPageScrollStateChanged(num: Int) {}
        })

        binding.imDelete.setOnClickListener {
            val ab = AlertDialog.Builder(this)
            ab.setPositiveButton(resources.getString(R.string.yes)) { dialog, id ->
                val b = fileArrayList[Position].delete()
                if (b) {
                    deleteFileAA(Position)
                }
            }
            ab.setNegativeButton(resources.getString(R.string.no)) { dialog, id -> dialog.cancel() }
            val alert = ab.create()
            alert.setTitle(resources.getString(R.string.do_u_want_to_dlt))
            alert.show()
        }

        binding.imShare.setOnClickListener {
            if (fileArrayList[Position].name.contains(".mp4")) {
                Log.d("SSSSS", "onClick: ${fileArrayList[Position]}")
                shareVideo(this, fileArrayList[Position].path)
            } else {
                shareImage(this, fileArrayList[Position].path)
            }
        }

        binding.imWhatsappShare.setOnClickListener {
            if (fileArrayList[Position].name.contains(".mp4")) {
                shareImageVideoOnWhatsapp(this, fileArrayList[Position].path, true)
            } else {
                shareImageVideoOnWhatsapp(this, fileArrayList[Position].path, false)
            }
        }

        binding.imClose.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()

    }

    fun deleteFileAA(position: Int) {
        fileArrayList.removeAt(position)
        showImagesAdapter.notifyDataSetChanged()
       toast(R.string.file_detected)
        if (fileArrayList.size == 0) {
            onBackPressed()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }
}