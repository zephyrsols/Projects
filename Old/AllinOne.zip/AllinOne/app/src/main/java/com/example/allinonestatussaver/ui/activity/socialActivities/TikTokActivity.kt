package com.example.allinonestatussaver.ui.activity.socialActivities

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentValues
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.api.CommonClassForAPI
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.model.TiktokModel
import com.example.allinonestatussaver.util.AppLangSessionManager
import com.example.allinonestatussaver.util.Utils
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAd
import com.facebook.ads.InterstitialAdListener
import io.reactivex.observers.DisposableObserver
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.util.Locale

class TikTokActivity : AppCompatActivity() {
    private var binding: ActivityFacebookBinding? = null
    var activity: TikTokActivity? = null
    var commonClassForAPI: CommonClassForAPI? = null
    private var VideoUrl: String? = null
    private var clipBoard: ClipboardManager? = null
    var IsWithWaternark = true
    var appLangSessionManager: AppLangSessionManager? = null
    private var interstitialAd: InterstitialAd? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layoutInflater: LayoutInflater? = null
        binding = ActivityFacebookBinding.inflate(
            layoutInflater!!
        )
        appLangSessionManager = AppLangSessionManager(activity)
        setLocale(appLangSessionManager!!.language)
        commonClassForAPI = CommonClassForAPI.getInstance(activity)
        Utils.createFileFolder()
        initViews()

//        AdsUtils.showFBBannerAdRect(activity, binding.bannerContainer);
//        FBInterstitialAdsINIT();
    }

    override fun onResume() {
        super.onResume()
        activity = this
        assert(activity != null)
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        PasteText()
    }

    private fun initViews() {
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        binding!!.backArrow.setOnClickListener { onBackPressed() }
        //        binding.imInfo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//            }
//        });

        //binding.layoutHowTo.imHowto1.setImageResource(R.drawable.tt1);
        //binding.layoutHowTo.imHowto2.setImageResource(R.drawable.tt2);
        //  binding.layoutHowTo.imHowto3.setImageResource(R.drawable.tt3);
        //binding.layoutHowTo.imHowto4.setImageResource(R.drawable.tt4);

//        Glide.with(activity)
//                .load(R.drawable.tt1)
//                .into(binding.layoutHowTo.imHowto1);
//
//        Glide.with(activity)
//                .load(R.drawable.tt2)
//                .into(binding.layoutHowTo.imHowto2);
//
//        Glide.with(activity)
//                .load(R.drawable.tt3)
//                .into(binding.layoutHowTo.imHowto3);
//
//        Glide.with(activity)
//                .load(R.drawable.tt4)
//                .into(binding.layoutHowTo.imHowto4);


//
//        binding.layoutHowTo.tvHowTo1.setText(getResources().getString(R.string.open_tiktok));
//        binding.layoutHowTo.tvHowTo3.setText(getResources().getString(R.string.open_tiktok));
//        if (!SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISSHOWHOWTOTT)) {
//            SharePrefs.getInstance(activity).putBoolean(SharePrefs.ISSHOWHOWTOTT, true);
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//        } else {
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.GONE);
//        }
        binding!!.download.setOnClickListener { v: View? ->
            IsWithWaternark = true
            val LL = binding!!.etText.text.toString()
            if (LL == "") {
                Utils.setToast(activity, resources.getString(R.string.enter_url))
            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
            } else {
                GetTikTokData()
                showInterstitial()
            }
        }
        binding!!.paste.setOnClickListener { v: View? ->
            IsWithWaternark = false
            val LL = binding!!.etText.text.toString()
            if (LL == "") {
                Utils.setToast(activity, resources.getString(R.string.enter_url))
            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
            } else {
                GetTikTokData()
                showInterstitial()
            }
        }

//        binding.LLOpenTikTok.setOnClickListener(v -> {
//            Intent launchIntent = activity.getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically.go");
//            Intent launchIntent1 = activity.getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
//            if (launchIntent != null) {
//                activity.startActivity(launchIntent);
//            } else if (launchIntent1 != null) {
//                activity.startActivity(launchIntent1);
//            } else {
//                Utils.setToast(activity, getResources().getString(R.string.app_not_available));
//            }
//
//        });
    }

    private fun GetTikTokData() {
        try {
            Utils.createFileFolder()
            val host = binding!!.etText.text.toString()
            if (host.contains("tiktok")) {
                Utils.showProgressDialog(activity)
                // new callGetTikTokData().execute(binding.etText.getText().toString());
                callVideoDownload(binding!!.etText.text.toString())
            } else {
                Utils.setToast(activity, "Enter Valid Url")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun callVideoDownload(Url: String) {
        try {
            val utils = Utils(activity)
            if (utils.isNetworkAvailable) {
                if (commonClassForAPI != null) {
                    commonClassForAPI!!.callTiktokVideo(tiktokObserver, Url)
                }
            } else {
                Utils.setToast(activity, "No Internet Connection")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private val tiktokObserver: DisposableObserver<TiktokModel?> =
        object : DisposableObserver<TiktokModel?>() {
            override fun onNext(tiktokModel: TiktokModel) {
                Utils.hideProgressDialog(activity)
                try {
                    if (tiktokModel.responsecode == "200") {
                        if (IsWithWaternark) {
                            Utils.startDownload(
                                tiktokModel.data!!.mainvideo,
                                Utils.RootDirectoryTikTok, activity, getFilenameFromURL(
                                    tiktokModel.data!!.mainvideo
                                )
                            )
                            binding!!.etText.setText("")
                        } else {
                            if (tiktokModel.data!!.videowithoutWaterMark != "") {
                                Utils.startDownload(
                                    tiktokModel.data!!.videowithoutWaterMark,
                                    Utils.RootDirectoryTikTok,
                                    activity,
                                    tiktokModel.data!!.userdetail + "_" + System.currentTimeMillis() + ".mp4"
                                )
                                binding!!.etText.setText("")
                            } else {
                                Utils.startDownload(
                                    tiktokModel.data!!.mainvideo,
                                    Utils.RootDirectoryTikTok, activity, getFilenameFromURL(
                                        tiktokModel.data!!.mainvideo
                                    )
                                )
                                binding!!.etText.setText("")
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(e: Throwable) {
                Utils.hideProgressDialog(activity)
                e.printStackTrace()
                Utils.showProgressDialog(activity)
                callGetTikTokData().execute(binding!!.etText.text.toString())
            }

            override fun onComplete() {
                Utils.hideProgressDialog(activity)
            }
        }

    private fun PasteText() {
        try {
            binding!!.etText.setText("")
            val CopyIntent = intent.getStringExtra("CopyIntent")
            if (CopyIntent == "") {
                if (!clipBoard!!.hasPrimaryClip()) {
                } else if (!clipBoard!!.primaryClipDescription!!
                        .hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
                ) {
                    if (clipBoard!!.primaryClip!!.getItemAt(0).text.toString()
                            .contains("tiktok.com")
                    ) {
                        binding!!.etText.setText(clipBoard!!.primaryClip!!.getItemAt(0).text.toString())
                    }
                } else {
                    val item = clipBoard!!.primaryClip!!.getItemAt(0)
                    if (item.text.toString().contains("tiktok.com")) {
                        binding!!.etText.setText(item.text.toString())
                    }
                }
            } else {
                if (CopyIntent!!.contains("tiktok.com")) {
                    binding!!.etText.setText(CopyIntent)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    internal inner class callGetTikTokData : AsyncTask<String?, Void?, Document?>() {
        var tikDoc: Document? = null
        override fun doInBackground(vararg p0: String?): Document? {
            TODO("Not yet implemented")
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected  fun dooInBackground(vararg urls: String): Document? {
            try {
                tikDoc = Jsoup.connect(urls[0]).get()
            } catch (e: IOException) {
                e.printStackTrace()
                Log.d(ContentValues.TAG, "doInBackground: Error")
            }
            return tikDoc
        }

        override fun onPostExecute(result: Document?) {
            Utils.hideProgressDialog(activity)
            try {
                // String URL = result.select("script[id=\"videoObject\"]").last().html();
                val URL = result!!.select("script[id=\"__NEXT_DATA__\"]").last().html()
                if (URL != "") {
                    try {
                        val jsonObject = JSONObject(URL)
                        VideoUrl = jsonObject.getJSONObject("props").getJSONObject("pageProps")
                            .getJSONObject("videoData").getJSONObject("itemInfos")
                            .getJSONObject("video").getJSONArray("urls")[0].toString()
                        if (IsWithWaternark) {
                            Utils.startDownload(
                                VideoUrl,
                                Utils.RootDirectoryTikTok,
                                activity,
                                "tiktok_" + System.currentTimeMillis() + ".mp4"
                            )
                        } else {
                            GetDownloadLinkWithoutWatermark().execute()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            }
        }
    }

    fun getFilenameFromURL(url: String?): String {
        return try {
            File(URL(url).path).name + ".mp4"
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            System.currentTimeMillis().toString() + ".mp4"
        }
    }

    private inner class GetDownloadLinkWithoutWatermark : AsyncTask<String?, String?, String?>() {
        var resp: String? = null
        override fun doInBackground(vararg p0: String?): String? {
            TODO("Not yet implemented")
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected  fun dooInBackground(vararg args: String): String? {
            try {
                resp = withoutWatermark(VideoUrl)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return resp
        }

        override fun onPostExecute(url: String?) {
            try {
                Utils.startDownload(
                    url,
                    Utils.RootDirectoryTikTok,
                    activity,
                    "tiktok_" + System.currentTimeMillis() + ".mp4"
                )
                VideoUrl = ""
                binding!!.etText.setText("")
            } catch (e: Exception) {
                Utils.setToast(activity, resources.getString(R.string.error_occurred))
            }
        }
    }

    fun withoutWatermark(url: String?): String {
        return try {
            val httpConn =
                URL(url).openConnection() as HttpURLConnection
            httpConn.requestMethod = "GET"
            httpConn.connect()
            val resCode = httpConn.responseCode
            val rd =
                BufferedReader(InputStreamReader(httpConn.inputStream))
            val result = StringBuffer()
            var str: String?
            while (true) {
                str = rd.readLine()
                if (str != null) {
                    result.append(str)
                    if (result.toString().contains("vid:")) {
                        try {
                            val VideoIdString =
                                result.substring(result.indexOf("vid:"))
                            val VID = VideoIdString.substring(0, 4)
                            if (VID == "vid:") {
                                break
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                } else {
                }
            }
            val VideoId = result.substring(result.indexOf("vid:"))
            val FinalVID =
                VideoId.substring(4, VideoId.indexOf("%")).replace("[^A-Za-z0-9]".toRegex(), "")
                    .trim { it <= ' ' }
            "http://api2.musical.ly/aweme/v1/play/?video_id=$FinalVID"
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun setLocale(lang: String?) {
        val myLocale = Locale(lang)
        val res = resources
        val dm = res.displayMetrics
        val conf = res.configuration
        conf.locale = myLocale
        res.updateConfiguration(conf, dm)
    }

    //FB INTERSTITIAL ADS : STARTED
    fun FBInterstitialAdsINIT() {
        interstitialAd =
            InterstitialAd(this, resources.getString(R.string.fb_placement_interstitial_id))
        // Set listeners for the Interstitial Ad
        interstitialAd!!.setAdListener(object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {
                // Interstitial ad displayed callback
                Log.e(ContentValues.TAG, "Interstitial ad displayed.")
            }

            override fun onInterstitialDismissed(ad: Ad) {
                // Interstitial dismissed callback
                Log.e(ContentValues.TAG, "Interstitial ad dismissed.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Ad error callback
            }

            override fun onAdLoaded(ad: Ad) {
                // Interstitial ad is loaded and ready to be displayed
                Log.d(ContentValues.TAG, "Interstitial ad is loaded and ready to be displayed!")
                // Show the ad
            }

            override fun onAdClicked(ad: Ad) {
                // Ad clicked callback
                Log.d(ContentValues.TAG, "Interstitial ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Ad impression logged callback
                Log.d(ContentValues.TAG, "Interstitial ad impression logged!")
            }
        })

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown
        interstitialAd!!.loadAd()
    }

    private fun showInterstitial() {
        if (interstitialAd != null && interstitialAd!!.isAdLoaded) {
            interstitialAd!!.show()
        }
    } //FB INTERSTITIAL ADS : END
}