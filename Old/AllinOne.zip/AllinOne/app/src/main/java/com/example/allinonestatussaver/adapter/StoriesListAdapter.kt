package com.example.allinonestatussaver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.allinonestatussaver.databinding.ItemsWhatsappViewBinding
import com.example.allinonestatussaver.model.story.ItemModel
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryInsta
import com.example.allinonestatussaver.util.Utils_status.startDownload


class StoriesListAdapter(private val context: Context, private val storyItemModelList: ArrayList<ItemModel?>?) :
    RecyclerView.Adapter<StoriesListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemsWhatsappViewBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val itemModel = storyItemModelList?.get(position)
        try {
            if (itemModel != null) {
                if (itemModel.media_type == 2) {
                    holder.binding.ivPlay.visibility = View.VISIBLE
                } else {
                    holder.binding.ivPlay.visibility = View.GONE
                }
            }
            if (itemModel != null) {
                Glide.with(context)
                    .load(itemModel.image_versions2?.candidates?.get(0)?.url)
                    .into(holder.binding.pcw)
            }

        } catch (ex: Exception) {
            ex.printStackTrace()
        }

        holder.binding.tvDownload.setOnClickListener {
            val url = if (itemModel!!.media_type == 2) {
                itemModel.video_versions?.get(0)?.url
            } else {
                itemModel.image_versions2?.candidates?.get(0)?.url
            }
            val fileName = if (itemModel.media_type == 2) {
                "story_${itemModel.id}.mp4"
            } else {
                "story_${itemModel.id}.png"
            }
            startDownload(url, RootDirectoryInsta, context, fileName)
        }
    }

    override fun getItemCount(): Int {
        return storyItemModelList?.size !!
    }

    inner class ViewHolder(val binding: ItemsWhatsappViewBinding) :
        RecyclerView.ViewHolder(binding.root)
}