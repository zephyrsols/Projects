package com.example.allinonestatussaver.ui.activity.socialActivities

import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.databinding.ActivityWebviewBinding

class WebviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWebviewBinding
    private var intentURL: String? = null
    private var intentTitle: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intentURL = intent.getStringExtra("URL")
        intentTitle = intent.getStringExtra("Title")

        binding.imBack.setOnClickListener {
            onBackPressed()
        }
        binding.TVTitle.text = intentTitle


        binding.swipeRefreshLayout.post {
            binding.swipeRefreshLayout.isRefreshing = true
            intentURL?.let { LoadPage(it) }
        }

        binding.swipeRefreshLayout.setOnRefreshListener {
            intentURL?.let { LoadPage(it) }
        }
    }

    private fun LoadPage(url: String) {
        binding.webView1.webViewClient = MyBrowser()
        binding.webView1.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.swipeRefreshLayout.isRefreshing = newProgress != 100
            }
        }
        binding.webView1.settings.loadsImagesAutomatically = true
        binding.webView1.settings.javaScriptEnabled = true
        binding.webView1.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        binding.webView1.loadUrl(url)
    }

    private inner class MyBrowser : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }
    }
}