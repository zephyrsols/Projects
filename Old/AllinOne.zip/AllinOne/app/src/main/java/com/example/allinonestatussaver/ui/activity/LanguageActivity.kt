package com.example.allinonestatussaver.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.window.OnBackInvokedDispatcher
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.BuildCompat
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivityLanguageBinding
import com.example.allinonestatussaver.extensionFun.baseConfig
import com.example.allinonestatussaver.sharedPreferencesLang.MySharePreferences
import com.example.allinonestatussaver.ui.onBoarding.IntroSliderActivity
import com.example.allinonestatussaver.util.CheckInternetConnection
import com.example.allinonestatussaver.util.changeLanguage
import com.example.allinonestatussaver.util.refreshLanguageStrings
import java.util.Locale

class LanguageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLanguageBinding
    var lang: String = "English"
    val mySharePreferences = MySharePreferences(this)
    var started = false

    lateinit var checkInternetConnection: CheckInternetConnection
    var buttonsIds: ArrayList<RadioButton> = arrayListOf()

    @SuppressLint("UnsafeOptInUsageError")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val lang =intent.getBooleanExtra("setting",false )

        binding = ActivityLanguageBinding.inflate(layoutInflater)
        loadLocale()
        setContentView(binding.root)
        Log.d("TAG12121", "onCreate: $lang")
        /* if (!lang){
             showPriorityAdmobInterstitial(true,getString(R.string.admob_interistitial_search_high),
                 getString(R.string.admob_interistitial_search_low)
                 , {
                     interstitialAdPriority = it
                 })
             loadAndReturnAd(
                 this@LanguageActivity,
                 resources.getString(R.string.admob_native_boarding)
             ) {
                 if (it != null) {
                     LocationTrackerAppClass.instance.nativeAdBoarding.value = it
                 }
             }
         }
         else{
             loadAndReturnAd(
                 this@LanguageActivity,
                 resources.getString(R.string.admob_native_lang_high)
             ) {
                 if (it != null) {
                     LocationTrackerAppClass.instance.nativeAdLang.value = it
                 } else {
                     loadAndReturnAd(
                         this@LanguageActivity,
                         resources.getString(R.string.admob_native_lang_low)
                     ) { it2 ->
                         if (it2 != null) {
                             LocationTrackerAppClass.instance.nativeAdLang.value = it2
                         }
                     }
                 }
             }
         }

         loadAd()*/
        checkInternetConnection = CheckInternetConnection(this)
        initListeners()
        if (BuildCompat.isAtLeastT()) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT
            ) {
                finish()
            }
        } else {
            onBackPressedDispatcher.addCallback(
                this, // lifecycle owner
                object : OnBackPressedCallback(true) {
                    override fun handleOnBackPressed() {
                        finish()

                    }
                })
        }
    }

    private fun initListeners() {
        binding.tvTitle.text = resources.getString(R.string.language)
        binding.tick.setOnClickListener {
            when (lang) {
                "English" -> {
                    baseConfig.appLanguage = "en"
                    next()

                }

                "Hindi" -> {
                    baseConfig.appLanguage = "hi"
                    next()

                }

                "Spanish" -> {
                    baseConfig.appLanguage = "es"
                    next()

                }

                "French" -> {
                    baseConfig.appLanguage = "fr"
                    next()

                }

                "Arabic" -> {
                    baseConfig.appLanguage = "ar"
                    next()

                }

                "Urdu" -> {
                    baseConfig.appLanguage = "ur"
                    next()

                }

                "Indonesia" -> {
                    baseConfig.appLanguage = "in"
                    next()

                }

                "Russia" -> {
                    baseConfig.appLanguage = "ru"
                    next()

                }

                "Afrikaans" -> {
                    baseConfig.appLanguage = "af"
                    next()

                }

                "Vietnamese" -> {
                    baseConfig.appLanguage = "vi"
                    next()

                }
                "Chinese" -> {
                    baseConfig.appLanguage = "zh"
                    next()

                }

                "German" -> {
                    baseConfig.appLanguage = "de"
                    next()

                }

                "Japanese" -> {
                    baseConfig.appLanguage = "ja"
                    next()

                }

                "Korean" -> {
                    baseConfig.appLanguage = "ko"
                    next()

                }

                "Thai" -> {
                    baseConfig.appLanguage = "th"
                    next()

                }
                "Portuguese" -> {
                    baseConfig.appLanguage = "pt"
                    next()

                }

            }
        }

        buttonsIds = arrayListOf(
            binding.english,
            binding.hindi,
            binding.spanish,
            binding.french,
            binding.arabic,
            binding.urdu,
            binding.indonesia,
            binding.russia,
            binding.african,
            binding.vietnamese,
            binding.china,
            binding.german,
            binding.japanese,
            binding.korean,
            binding.thailand ,
            binding.portuguese
        )

        buttonsIds.forEachIndexed { index, mRadioButton ->
            mRadioButton.setOnClickListener {
                mRadioButton.isChecked = true
                lang = mRadioButton.text.toString()
                buttonsIds.forEachIndexed { index, radioButton ->
                    if (radioButton.id != mRadioButton.id) {
                        radioButton.isChecked = false
                    }
                }

            }

        }
        arrayListOf(
            binding.clEnglish,
            binding.clHindi,
            binding.clSpanish,
            binding.clFrench,
            binding.clArabic,
            binding.clUrdu,
            binding.clIndonesia,
            binding.clRussia,
            binding.clAfrican,
            binding.clVietnamese,
            binding.clChina,
            binding.clGermany,
            binding.clJapanese,
            binding.clKorean,
            binding.clThailand,
            binding.clPortuguese
        ).forEachIndexed { index, constraintLayout ->
            constraintLayout.setOnClickListener {
                handleRadioButton(buttonsIds[index])
            }
        }

    }

    private fun handleRadioButton(mButton: RadioButton) {
        buttonsIds.forEach { button ->
            if (button.id == mButton.id) {
                button.isChecked = true
                lang = button.text.toString()
            } else {
                button.isChecked = false
            }

        }

    }

    fun next() {
        changeLanguage(baseConfig.appLanguage.toString())
        refreshLanguageStrings()
        if (!baseConfig.appStarted) {
            baseConfig.appStarted = true
            startActivity(Intent(this@LanguageActivity, IntroSliderActivity::class.java))
            finish()
            return
        }
        finish()
    }

    fun radio_button_click(view: View) {
        // Get the clicked radio button instance
//        val radio: RadioButton = findViewById(binding.radioGroup.checkedRadioButtonId)
//        Toast.makeText(applicationContext,"On click : ${radio.text}",
//            Toast.LENGTH_SHORT).show()
    }

    private fun setLocale(language: String) {

        val locale = Locale(language)
        Locale.setDefault(locale)

        val configuration = Configuration()
        configuration.locale = locale
        baseContext.resources.updateConfiguration(
            configuration,
            baseContext.resources.displayMetrics
        )

        val editor: SharedPreferences.Editor = getSharedPreferences("Settings", MODE_PRIVATE).edit()
        editor.putString("app_lang", language)
        editor.apply()
    }

    private fun loadLocale() {
//        val preferences: SharedPreferences = getSharedPreferences("Settings", MODE_PRIVATE)
//        val language = preferences.getString("app_lang", "")
        val language = baseConfig.appLanguage
        language?.let {
            setLocale(it)
            when (it) {
                "en" -> {
                    binding.english.isChecked = true
                }

                "hi" -> {
                    binding.hindi.isChecked = true

                }

                "es" -> {
                    binding.spanish.isChecked = true

                }

                "fr" -> {
                    binding.french.isChecked = true

                }

                "ar" -> {
                    binding.arabic.isChecked = true

                }

                "ur" -> {
                    binding.urdu.isChecked = true
                }

                "in" -> {
                    binding.indonesia.isChecked = true
                }
                "ru" -> {
                    binding.russia.isChecked = true
                }
                "af" -> {
                    binding.african.isChecked = true
                }
                "vi" -> {
                    binding.vietnamese.isChecked = true
                }

                "zh" -> {
                    binding.china.isChecked = true
                }

                "de" -> {
                    binding.german.isChecked = true
                }
                "ja" -> {
                    binding.japanese.isChecked = true
                }
                "ko" -> {
                    binding.korean.isChecked = true
                }
                "th" -> {
                    binding.thailand.isChecked = true
                }
                "pt" -> {
                    binding.portuguese.isChecked = true
                }
            }

        }
    }
}