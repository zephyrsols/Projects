package com.example.allinonestatussaver.ui.frag

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil.inflate
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.allinonestatussaver.adapter.WhatsappStatusAdapter
import com.example.allinonestatussaver.databinding.FragmentWhatsappImageBinding
import com.example.allinonestatussaver.model.WhatsappStatusModel
import java.io.File
import java.util.Arrays

class WhatsappVideoFragment : Fragment() {
    private lateinit var binding: FragmentWhatsappImageBinding
    private lateinit var statusModelArrayList: ArrayList<WhatsappStatusModel>
    private lateinit var whatsappStatusAdapter: WhatsappStatusAdapter
    private lateinit var allfiles: Array<File>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentWhatsappImageBinding.inflate(inflater, container, false)
        initViews()
        return binding.root
    }

    private fun initViews() {
        statusModelArrayList = ArrayList()
        getData()
        binding.swiperefresh.setOnRefreshListener {
            statusModelArrayList.clear()
            getData()
            binding.swiperefresh.isRefreshing = false
        }
    }

    private fun getData() {
        val targetPath =
            "${Environment.getExternalStorageDirectory().absolutePath}/WhatsApp/Media/.Statuses"
        val targetDirector = File(targetPath)
        allfiles = targetDirector.listFiles() ?: arrayOf()

        val targetPathBusiness =
            "${Environment.getExternalStorageDirectory().absolutePath}/WhatsApp Business/Media/.Statuses"
        val targetDirectorBusiness = File(targetPathBusiness)
        val allfilesBusiness = targetDirectorBusiness.listFiles() ?: arrayOf()

        try {
            allfiles.sortWith(Comparator { o1, o2 ->
                when {
                    o1.lastModified() > o2.lastModified() -> -1
                    o1.lastModified() < o2.lastModified() -> 1
                    else -> 0
                }
            })

            allfiles.forEachIndexed { i, file ->
                if (Uri.fromFile(file).toString().endsWith(".mp4")) {
                    val whatsappStatusModel = WhatsappStatusModel(
                        "WhatsStatus: ${i + 1}",
                        Uri.fromFile(file),
                        file.absolutePath,
                        file.name
                    )
                    statusModelArrayList.add(whatsappStatusModel)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            allfilesBusiness.sortWith(Comparator { o1, o2 ->
                when {
                    o1.lastModified() > o2.lastModified() -> -1
                    o1.lastModified() < o2.lastModified() -> 1
                    else -> 0
                }
            })

            allfilesBusiness.forEachIndexed { i, file ->
                if (Uri.fromFile(file).toString().endsWith(".mp4")) {
                    val whatsappStatusModel = WhatsappStatusModel(
                        "WhatsStatusB: ${i + 1}",
                        Uri.fromFile(file),
                        file.absolutePath,
                        file.name
                    )
                    statusModelArrayList.add(whatsappStatusModel)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (statusModelArrayList.size != 0) {
            binding.tvNoResult.visibility = View.GONE
        } else {
            binding.tvNoResult.visibility = View.VISIBLE
        }
        whatsappStatusAdapter = WhatsappStatusAdapter(requireActivity(), statusModelArrayList)
        binding.rvFileList.layoutManager = LinearLayoutManager(activity)
        binding.rvFileList.adapter = whatsappStatusAdapter
    }
}