package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class User : Serializable {
    @SerializedName("pk")
    var pk: Long = 0

    @SerializedName("username")
    var username: String? = null

    @SerializedName("full_name")
    var full_name: String? = null

    @SerializedName("is_private")
    var isIs_private = false
        private set

    @SerializedName("profile_pic_url")
    var profile_pic_url: String? = null

    @SerializedName("profile_pic_id")
    var profile_pic_id: String? = null

    @SerializedName("is_verified")
    var isIs_verified = false
        private set

    @SerializedName("media_count")
    var media_count = 0

    @SerializedName("follower_count")
    var follower_count = 0

    @SerializedName("following_count")
    var following_count = 0

    @SerializedName("biography")
    var biography: String? = null

    @SerializedName("total_igtv_videos")
    var total_igtv_videos: String? = null

    @SerializedName("hd_profile_pic_url_info")
    var hdProfileModel: HDProfileModel? = null

    @SerializedName("mutual_followers_count")
    var mutual_followers_count = 0

    @SerializedName("profile_context")
    var profile_context: String? = null
    fun setIs_private(is_private: Boolean) {
        isIs_private = is_private
    }

    fun setIs_verified(is_verified: Boolean) {
        isIs_verified = is_verified
    }
}