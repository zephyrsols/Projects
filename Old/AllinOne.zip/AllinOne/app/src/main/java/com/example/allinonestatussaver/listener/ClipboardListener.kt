package com.example.allinonestatussaver.listener

import android.content.ClipboardManager.OnPrimaryClipChangedListener

abstract class ClipboardListener : OnPrimaryClipChangedListener