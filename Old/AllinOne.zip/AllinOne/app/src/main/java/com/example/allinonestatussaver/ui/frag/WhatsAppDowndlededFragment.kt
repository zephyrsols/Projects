package com.example.allinonestatussaver.ui.frag

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil.inflate
import androidx.fragment.app.Fragment
import com.example.allinonestatussaver.adapter.FileListAdapter
import com.example.allinonestatussaver.databinding.FragmentHistoryBinding
import com.example.allinonestatussaver.interfaces.FileListClickInterface
import com.example.allinonestatussaver.ui.activity.FullViewActivity
import com.example.allinonestatussaver.ui.activity.GalleryActivity
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryWhatsappShow
import java.io.File

class WhatsAppDowndlededFragment : Fragment(), FileListClickInterface {
    private lateinit var binding: FragmentHistoryBinding
    private var fileListAdapter: FileListAdapter? = null
    private var fileArrayList: ArrayList<File>? = null
    private var activity: GalleryActivity? = null
    override fun onAttach(_context: Context) {
        super.onAttach(_context)
        activity = _context as GalleryActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            val mParam1 = requireArguments().getString("m")
        }
    }

    override fun onResume() {
        super.onResume()
        activity = getActivity() as GalleryActivity?
        allFiles
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHistoryBinding.inflate(inflater, container, false)
        initViews()
        return binding.root
    }

    private fun initViews() {
        binding.swiperefresh.setOnRefreshListener {
            allFiles
            binding.swiperefresh.isRefreshing = false
        }
    }

    private val allFiles: Unit
        private get() {
            fileArrayList = ArrayList()
            val files: Array<File> = RootDirectoryWhatsappShow.listFiles()
            if (files != null) {
                for (file in files) {
                    fileArrayList!!.add(file)
                }
                fileListAdapter =
                    activity?.let { FileListAdapter(it, fileArrayList!!, this@WhatsAppDowndlededFragment) }
                binding.rvFileList.setAdapter(fileListAdapter)
            }
        }

    override fun getPosition(position: Int, file: File?) {
        val inNext = Intent(activity, FullViewActivity::class.java)
        inNext.putExtra("ImageDataFile", fileArrayList)
        inNext.putExtra("Position", position)
        activity?.startActivity(inNext)
    }

    companion object {
        fun newInstance(param1: String?): WhatsAppDowndlededFragment {
            val fragment = WhatsAppDowndlededFragment()
            val args = Bundle()
            args.putString("m", param1)
            fragment.arguments = args
            return fragment
        }
    }
}