//package com.example.allinonestatussaver.ui.activity.socialActivities
//
//import android.content.ClipDescription
//import android.content.ClipboardManager
//import android.content.ContentValues
//import android.os.AsyncTask
//import android.os.Bundle
//import android.provider.Settings
//import android.text.TextUtils
//import android.util.Log
//import android.util.Patterns
//import android.view.LayoutInflater
//import android.view.View
//import androidx.appcompat.app.AppCompatActivity
//import com.example.allinonestatussaver.R
//import com.example.allinonestatussaver.api.CommonClassForAPI
//import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
//import com.example.allinonestatussaver.util.AppLangSessionManager
//import com.example.allinonestatussaver.util.Utils
//import com.facebook.ads.Ad
//import com.facebook.ads.AdError
//import com.facebook.ads.InterstitialAd
//import com.facebook.ads.InterstitialAdListener
//import com.google.gson.JsonObject
//import io.reactivex.observers.DisposableObserver
//import org.json.JSONObject
//import org.jsoup.Jsoup
//import org.jsoup.nodes.Document
//import java.io.IOException
//import java.net.URI
//import java.net.URL
//import java.nio.charset.Charset
//import java.util.Collections
//import java.util.Locale
//
//class SnackVideoActivity : AppCompatActivity() {
//    var binding: ActivityFacebookBinding? = null
//    var activity: SnackVideoActivity? = null
//    var commonClassForAPI: CommonClassForAPI? = null
//    private var VideoUrl: String? = null
//    private var clipBoard: ClipboardManager? = null
//    var appLangSessionManager: AppLangSessionManager? = null
//    private var interstitialAd: InterstitialAd? = null
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        val layoutInflater: LayoutInflater? = null
//        binding = ActivityFacebookBinding.inflate(
//            layoutInflater!!
//        )
//        commonClassForAPI = CommonClassForAPI.getInstance(activity)
//        Utils.createFileFolder()
//        initViews()
//        appLangSessionManager = AppLangSessionManager(activity)
//        setLocale(appLangSessionManager!!.language)
//            //
////        AdsUtils.showFBBannerAdRect(activity, binding.bannerContainer);
////        FBInterstitialAdsINIT();
//        //
//    }
//
//    override fun onResume() {
//        super.onResume()
//        activity = this
//        assert(activity != null)
//        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
//        PasteText()
//    }
//
//    private fun initViews() {
//        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
//        binding!!.backArrow.setOnClickListener { view: View? -> onBackPressed() }
//
//
//        //        binding.imInfo.setOnClickListener(view -> binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE));
////
////        Glide.with(activity)
////                .load(R.drawable.sn1)
////                .into(binding.layoutHowTo.imHowto1);
////
////        Glide.with(activity)
////                .load(R.drawable.sn2)
////                .into(binding.layoutHowTo.imHowto2);
////
////        Glide.with(activity)
////                .load(R.drawable.sn1)
////                .into(binding.layoutHowTo.imHowto3);
////
////        Glide.with(activity)
////                .load(R.drawable.sn2)
////                .into(binding.layoutHowTo.imHowto4);
////
////        binding.layoutHowTo.tvHowToHeadOne.setVisibility(View.GONE);
////        binding.layoutHowTo.LLHowToOne.setVisibility(View.GONE);
////        binding.layoutHowTo.tvHowToHeadTwo.setText(getResources().getString(R.string.how_to_download));
////        binding.layoutHowTo.tvHowTo1.setText(getResources().getString(R.string.open_snack));
////        binding.layoutHowTo.tvHowTo3.setText(getResources().getString(R.string.cop_link_from_snack));
////        if (!SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISSHOWHOWTOSNACK)) {
////            SharePrefs.getInstance(activity).putBoolean(SharePrefs.ISSHOWHOWTOSNACK, true);
////            binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
////        } else {
////            binding.layoutHowTo.LLHowToLayout.setVisibility(View.GONE);
////        }
//        binding!!.download.setOnClickListener { v: View? ->
//            val LL = binding!!.etText.text.toString()
//            if (LL == "") {
//                Utils.setToast(activity, resources.getString(R.string.enter_url))
//            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
//                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
//            } else {
//                GetsnackvideoData()
//            }
//        }
//        binding!!.paste.setOnClickListener { v: View? -> PasteText() }
//
////        binding.LLOpenTwitter.setOnClickListener(v -> {
////            Utils.OpenApp(activity, "com.kwai.bulldog");
////        });
//    }
//
//    private fun GetsnackvideoData() {
//        try {
//            Utils.createFileFolder()
//            val url = URL(binding!!.etText.text.toString())
//            val host = url.host
//            if (host.contains("snackvideo")) {
//                Utils.showProgressDialog(activity)
//                callGetsnackvideoData().execute(binding!!.etText.text.toString())
//            } else if (host.contains("sck.io")) {
//                getUrlData(binding!!.etText.text.toString())
//            } else {
//                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//
//    private fun PasteText() {
//        try {
//            binding!!.etText.setText("")
//            val CopyIntent = intent.getStringExtra("CopyIntent")
//            if (CopyIntent == "") {
//                if (!clipBoard!!.hasPrimaryClip()) {
//                } else if (!clipBoard!!.primaryClipDescription!!
//                        .hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
//                ) {
//                    if (clipBoard!!.primaryClip!!
//                            .getItemAt(0).text.toString()
//                            .contains("snackvideo") || clipBoard!!.primaryClip!!
//                            .getItemAt(0).text.toString().contains("sck.io")
//                    ) {
//                        binding!!.etText.setText(clipBoard!!.primaryClip!!.getItemAt(0).text.toString())
//                    }
//                } else {
//                    val item = clipBoard!!.primaryClip!!.getItemAt(0)
//                    if (item.text.toString().contains("snackvideo") || item.text.toString()
//                            .contains("sck.io")
//                    ) {
//                        binding!!.etText.setText(item.text.toString())
//                    }
//                }
//            } else {
//                if (CopyIntent!!.contains("snackvideo") || CopyIntent.contains("sck.io")) {
//                    binding!!.etText.setText(CopyIntent)
//                }
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//
//    fun getUrlData(str: String?) {
//        val uri: URI?
//        uri = try {
//            URI(str)
//        } catch (e: Exception) {
//            e.printStackTrace()
//            null
//        }
//        val split = uri!!.path.split("/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
//        val str2 = split[split.size - 1]
//        val str3 = "android"
//        val str4 = "8c46a905"
//        val sb = StringBuilder("ANDROID_")
//        sb.append(Settings.Secure.getString(contentResolver, "android_id"))
//        val arrayList: ArrayList<*> = ArrayList<Any?>()
//        val arrayList2: ArrayList<*> = ArrayList<Any?>()
////        arrayList.add("mod=OnePlus(ONEPLUS A5000)")
////        arrayList.add("lon=0")
////        arrayList.add("country_code=in")
////        val sb2 = StringBuilder()
////        sb2.append("did=")
////        sb2.append(sb)
////        arrayList.add(sb2.toString())
////        arrayList.add("app=1")
////        arrayList.add("oc=UNKNOWN")
////        arrayList.add("egid=")
////        arrayList.add("ud=0")
////        arrayList.add("c=GOOGLE_PLAY")
////        arrayList.add("sys=KWAI_BULLDOG_ANDROID_9")
////        arrayList.add("appver=2.7.1.153")
////        arrayList.add("mcc=0")
////        arrayList.add("language=en-in")
////        arrayList.add("lat=0")
////        arrayList.add("ver=2.7")
////        arrayList2.addAll(arrayList)
//        val sb3 = StringBuilder()
//        sb3.append("shortKey=")
//        sb3.append(str2)
////        arrayList2.add(sb3.toString())
//        val sb4 = StringBuilder()
//        sb4.append("os=")
//        sb4.append(str3)
////        arrayList2.add(sb4.toString())
//        val sb5 = StringBuilder()
//        sb5.append("client_key=")
//        sb5.append(str4)
////        arrayList2.add(sb5.toString())
//        try {
////            Collections.sort<Com parable<*>>(arrayList2)
//        } catch (e2: Exception) {
//            e2.printStackTrace()
//        }
//        val clockKey: String = com.yxcorp.gft.util.CPU.getClockData(
//            this,
//            TextUtils.join("", arrayList2).toByteArray(Charset.forName("UTF-8")),
//            0
//        )
//
//        val sb6 = StringBuilder()
//        sb6.append("https://g-api.snackvideo.com/rest/bulldog/share/get?")
//        sb6.append(TextUtils.join("&", arrayList))
//        try {
//            val utils = Utils(activity)
//            if (utils.isNetworkAvailable) {
//                if (commonClassForAPI != null) {
//                    Utils.showProgressDialog(activity)
//                    commonClassForAPI!!.callSnackVideoData(
//                        observer,
//                        sb6.toString(),
//                        str2,
//                        str3,
//                        clockKey,
//                        str4
//                    )
//                }
//            } else {
//                Utils.setToast(activity, resources.getString(R.string.no_net_conn))
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//
//    private val observer: DisposableObserver<JsonObject?> =
//        object : DisposableObserver<JsonObject?>() {
//            override fun onNext(jsonObject: JsonObject) {
//                Utils.hideProgressDialog(activity)
//                try {
//                    val photo = jsonObject["photo"].asJsonObject
//                    val mainArray = photo["main_mv_urls"].asJsonArray
//                    VideoUrl = mainArray[0].asJsonObject["url"].asString
//                    Utils.startDownload(
//                        VideoUrl,
//                        Utils.RootDirectorySnackVideo,
//                        activity,
//                        "snackvideo_" + System.currentTimeMillis() + ".mp4"
//                    )
//                    VideoUrl = ""
//                    binding!!.etText.setText("")
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                    Utils.setToast(activity, resources.getString(R.string.no_media_on_snackvideo))
//                }
//            }
//
//            override fun onError(e: Throwable) {
//                Utils.hideProgressDialog(activity)
//                e.printStackTrace()
//            }
//
//            override fun onComplete() {
//                Utils.hideProgressDialog(activity)
//            }
//        }
//
//    fun setLocale(lang: String?) {
//        val myLocale = Locale(lang)
//        val res = resources
//        val dm = res.displayMetrics
//        val conf = res.configuration
//        conf.locale = myLocale
//        res.updateConfiguration(conf, dm)
//    }
//
//    internal inner class callGetsnackvideoData : AsyncTask<String?, Void?, Document?>() {
//        var snackvideoDoc: Document? = null
//        override fun doInBackground(vararg p0: String?): Document? {
//            TODO("Not yet implemented")
//        }
//
//        override fun onPreExecute() {
//            super.onPreExecute()
//        }
//
//        protected  fun doInBackground(vararg urls: String): Document? {
//            try {
//                snackvideoDoc = Jsoup.connect(urls[0]).get()
//            } catch (e: IOException) {
//                e.printStackTrace()
//                Log.d(ContentValues.TAG, "doInBackground: Error")
//            }
//            return snackvideoDoc
//        }
//
//        override fun onPostExecute(result: Document?) {
//            Utils.hideProgressDialog(activity)
//            try {
//                val element = result!!.select("script")
//                var URL = ""
//                for (script in element) {
//                    var a = script.data()
//                    if (a.contains("window.__INITIAL_STATE__")) {
//                        a = a.substring(a.indexOf("{"), a.indexOf("};")) + "}"
//                        URL = a
//                        break
//                    }
//                }
//                if (URL != "") {
//                    try {
//                        val jsonObject = JSONObject(URL)
//                        VideoUrl = jsonObject.getJSONObject("sharePhoto").getString("mp4Url")
//                        val Url = jsonObject.getString("shortUrl")
//                        getUrlData(Url)
//                        VideoUrl = ""
//                        binding!!.etText.setText("")
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                }
//            } catch (e: NullPointerException) {
//                e.printStackTrace()
//            }
//        }
//    }
//
//    //FB INTERSTITIAL ADS : STARTED
//    fun FBInterstitialAdsINIT() {
//        interstitialAd =
//            InterstitialAd(this, resources.getString(R.string.fb_placement_interstitial_id))
//        // Set listeners for the Interstitial Ad
//        interstitialAd!!.setAdListener(object : InterstitialAdListener {
//            override fun onInterstitialDisplayed(ad: Ad) {
//                // Interstitial ad displayed callback
//                Log.e(ContentValues.TAG, "Interstitial ad displayed.")
//            }
//
//            override fun onInterstitialDismissed(ad: Ad) {
//                // Interstitial dismissed callback
//                Log.e(ContentValues.TAG, "Interstitial ad dismissed.")
//            }
//
//            override fun onError(ad: Ad, adError: AdError) {
//                // Ad error callback
//            }
//
//            override fun onAdLoaded(ad: Ad) {
//                // Interstitial ad is loaded and ready to be displayed
//                Log.d(ContentValues.TAG, "Interstitial ad is loaded and ready to be displayed!")
//                // Show the ad
//            }
//
//            override fun onAdClicked(ad: Ad) {
//                // Ad clicked callback
//                Log.d(ContentValues.TAG, "Interstitial ad clicked!")
//            }
//
//            override fun onLoggingImpression(ad: Ad) {
//                // Ad impression logged callback
//                Log.d(ContentValues.TAG, "Interstitial ad impression logged!")
//            }
//        })
//
//        // For auto play video ads, it's recommended to load the ad
//        // at least 30 seconds before it is shown
//        interstitialAd!!.loadAd()
//    }
//
//    private fun showInterstitial() {
//        if (interstitialAd != null && interstitialAd!!.isAdLoaded) {
//            interstitialAd!!.show()
//        }
//    } //FB INTERSTITIAL ADS : END
//}