package com.example.allinonestatussaver.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class EdgeSidecarToChildren : Serializable {

    @SerializedName("edges")
    private var edges: List<Edge?>? = null

    fun getEdges(): List<Edge?>? {
        return edges
    }

    fun setEdges(edges: List<Edge?>?) {
        this.edges = edges
    }
}