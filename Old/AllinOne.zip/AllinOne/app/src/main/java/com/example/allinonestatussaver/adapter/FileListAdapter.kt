package com.example.allinonestatussaver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ItemsFileViewBinding
import com.example.allinonestatussaver.interfaces.FileListClickInterface
import java.io.File

class FileListAdapter(
    private val context: Context,
    private val fileArrayList: ArrayList<File>,
    private val fileListClickInterface: FileListClickInterface
) : RecyclerView.Adapter<FileListAdapter.ViewHolder>() {

    private var layoutInflater: LayoutInflater? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        if (layoutInflater == null) {
            layoutInflater = LayoutInflater.from(parent.context)
        }
        val binding = ItemsFileViewBinding.inflate(layoutInflater!!, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val fileItem = fileArrayList[position]

        try {
            val extension = fileItem.name.substring(fileItem.name.lastIndexOf("."))
            if (extension == ".mp4") {
                holder.binding.ivPlay.visibility = View.VISIBLE
            } else {
                holder.binding.ivPlay.visibility = View.GONE
            }
            Glide.with(context)
                .load(fileItem.path)
                .into(holder.binding.pc)
        } catch (ex: Exception) {
            // Handle exception if needed
        }

        holder.binding.rlMain.setOnClickListener {
            fileListClickInterface.getPosition(position, fileItem)
        }
    }

    override fun getItemCount(): Int {
        return fileArrayList.size
    }

    inner class ViewHolder(val binding: ItemsFileViewBinding) : RecyclerView.ViewHolder(binding.root)
}