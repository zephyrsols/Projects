package com.example.allinonestatussaver.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class TiktokDataModel : Serializable {
    @SerializedName("mainvideo")
    var mainvideo: String? = null

    @SerializedName("videowithoutWaterMark")
    var videowithoutWaterMark: String? = null

    @SerializedName("userdetail")
    var userdetail: String? = null

    @SerializedName("thumbnail")
    var thumbnail: String? = null
}