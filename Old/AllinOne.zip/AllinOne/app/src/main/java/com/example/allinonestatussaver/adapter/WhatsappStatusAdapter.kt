package com.example.allinonestatussaver.adapter

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ItemsWhatsappViewBinding
import com.example.allinonestatussaver.model.WhatsappStatusModel
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryWhatsappShow
import com.example.allinonestatussaver.util.Utils_status.createFileFolder
import org.apache.commons.io.FileUtils
import java.io.File
import java.io.IOException

class WhatsappStatusAdapter(
    private val context: Context,
    private val fileArrayList: ArrayList<WhatsappStatusModel>
) : RecyclerView.Adapter<WhatsappStatusAdapter.ViewHolder>() {

    var SaveFilePath = "$RootDirectoryWhatsappShow/"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemsWhatsappViewBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val fileItem = fileArrayList[position]
        if (fileItem.uri.toString().endsWith(".mp4")) {
            holder.binding.ivPlay.visibility = View.VISIBLE
        } else {
            holder.binding.ivPlay.visibility = View.GONE
        }
        Glide.with(context)
            .load(fileItem.path)
            .into(holder.binding.pcw)

        holder.binding.tvDownload.setOnClickListener {
            createFileFolder()
            val path = fileItem.path
            val filename = path.substring(path.lastIndexOf("/") + 1)
            val file = File(path)
            val destFile = File(SaveFilePath)
            try {
                FileUtils.copyFileToDirectory(file, destFile)
            } catch (e: IOException) {
                e.printStackTrace()
            }
            val fileNameChange = filename.substring(12)
            val newFile = File("$SaveFilePath$fileNameChange")
            var contentType = "image/*"
            contentType = if (fileItem.uri.toString().endsWith(".mp4")) {
                "video/*"
            } else {
                "image/*"
            }
            MediaScannerConnection.scanFile(
                context, arrayOf(newFile.absolutePath), arrayOf(contentType),
                object : MediaScannerConnection.MediaScannerConnectionClient {
                    override fun onMediaScannerConnected() {}
                    override fun onScanCompleted(path: String, uri: Uri) {}
                }
            )

            val from = File(SaveFilePath, filename)
            val to = File(SaveFilePath, fileNameChange)
            from.renameTo(to)

            Toast.makeText(
                context,
                context.resources.getString(R.string.saved_to) + SaveFilePath + fileNameChange,
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun getItemCount(): Int {
        return fileArrayList.size
    }

    class ViewHolder(val binding: ItemsWhatsappViewBinding) :
        RecyclerView.ViewHolder(binding.root)

}