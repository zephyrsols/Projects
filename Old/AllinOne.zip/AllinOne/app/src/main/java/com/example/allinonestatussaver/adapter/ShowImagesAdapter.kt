package com.example.allinonestatussaver.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.ui.activity.FullViewActivity
import com.example.allinonestatussaver.util.Utils_status.shareImage
import com.example.allinonestatussaver.util.Utils_status.shareVideo
import java.io.File

class ShowImagesAdapter(
    private val context: Context,
    private val imageList: ArrayList<File>,
    fullViewActivity: FullViewActivity
) : PagerAdapter() {
    private val inflater: LayoutInflater
    var fullViewActivity: FullViewActivity

    init {
        this.fullViewActivity = fullViewActivity
        inflater = LayoutInflater.from(context)
    }

    override fun getItemPosition(`object`: Any): Int {
        return POSITION_NONE
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun instantiateItem(view: ViewGroup, position: Int): Any {
        val imageLayout: View = inflater.inflate(R.layout.slidingimages_layout, view, false)!!
        val imageView = imageLayout.findViewById<ImageView>(R.id.im_fullViewImage)
        val im_vpPlay = imageLayout.findViewById<ImageView>(R.id.im_vpPlay)
        val im_share = imageLayout.findViewById<ImageView>(R.id.im_share)
        val im_delete = imageLayout.findViewById<ImageView>(R.id.im_delete)
        Glide.with(context).load(imageList[position].path).into(imageView)
        view.addView(imageLayout, 0)
        val extension =
            imageList[position].name.substring(imageList[position].name.lastIndexOf("."))
        if (extension == ".mp4") {
            im_vpPlay.visibility = View.VISIBLE
        } else {
            im_vpPlay.visibility = View.GONE
        }
        im_vpPlay.setOnClickListener { v: View? ->
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(imageList[position].path), "video/*")
            context.startActivity(intent)
        }
        im_delete.setOnClickListener {
            val b = imageList[position].delete()
            if (b) {
                fullViewActivity.deleteFileAA(position)
            }
        }
        im_share.setOnClickListener {
            val extension = imageList[position].name.substring(
                imageList[position].name.lastIndexOf(".")
            )
            if (extension == ".mp4") {
                shareVideo(context, imageList[position].path)
            } else {
                shareImage(context, imageList[position].path)
            }
        }
        return imageLayout
    }

    override fun getCount(): Int {
        return imageList.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun restoreState(state: Parcelable?, loader: ClassLoader?) {}
    override fun saveState(): Parcelable? {
        return null
    }
}