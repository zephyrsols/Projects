package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class VideoVersionModel : Serializable {
    @SerializedName("type")
    var type = 0

    @SerializedName("width")
    var width = 0

    @SerializedName("height")
    var height = 0

    @SerializedName("url")
    var url: String? = null

    @SerializedName("id")
    var id: String? = null
}