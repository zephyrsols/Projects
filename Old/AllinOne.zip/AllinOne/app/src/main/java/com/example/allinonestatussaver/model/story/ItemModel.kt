package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ItemModel : Serializable {
    @SerializedName("taken_at")
    var taken_at: Long = 0

    @SerializedName("pk")
    var pk: Long = 0

    @SerializedName("id")
    var id: String? = null

    @SerializedName("device_timestamp")
    var device_timestamp: Long = 0

    @SerializedName("media_type")
    var media_type = 0

    @SerializedName("code")
    var code: String? = null

    @SerializedName("client_cache_key")
    var client_cache_key: String? = null

    @SerializedName("filter_type")
    var filter_type = 0

    @SerializedName("image_versions2")
    var image_versions2: ImageVersionModel? = null

    @SerializedName("original_width")
    var original_width = 0

    @SerializedName("original_height")
    var original_height = 0

    @SerializedName("video_versions")
    var video_versions: ArrayList<VideoVersionModel>? = null

    @SerializedName("has_audio")
    var isHas_audio = false

    @SerializedName("video_duration")
    var video_duration = 0.0

    @SerializedName("caption_is_edited")
    var isCaption_is_edited = false

    @SerializedName("caption_position")
    var caption_position = 0

    @SerializedName("is_reel_media")
    var isIs_reel_media = false
        private set

    @SerializedName("photo_of_you")
    var isPhoto_of_you = false

    @SerializedName("organic_tracking_token")
    var organic_tracking_token: String? = null

    @SerializedName("expiring_at")
    var expiring_at: Long = 0

    @SerializedName("can_reshare")
    var isCan_reshare = false

    @SerializedName("can_reply")
    var isCan_reply = false
    fun setIs_reel_media(is_reel_media: Boolean) {
        isIs_reel_media = is_reel_media
    }
}