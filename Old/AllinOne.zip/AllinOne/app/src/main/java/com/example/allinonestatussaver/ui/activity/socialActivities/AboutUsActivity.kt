/*
package com.example.allinonestatussaver.ui.activity.socialActivities

import android.content.Intent
import android.content.res.Resources
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.util.Utils_status.PrivacyPolicyUrl
import java.util.Locale

class AboutUsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutUsBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutUsBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.RLPrivacyPolicy.setOnClickListener {
            val i = Intent(this, WebviewActivity::class.java)
            i.putExtra("URL", PrivacyPolicyUrl)
            i.putExtra("Title", resources.getString(R.string.privacy_policy))
            startActivity(i)
        }

        binding.imBack.setOnClickListener {
            onBackPressed()
        }

        binding.RLWebsite.setOnClickListener {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(resources.getString(R.string.website_tag)))
                startActivity(browserIntent)
            } catch (ex: Exception) {
                Log.d("WebsiteTag", "onClick: $ex")
            }
        }

        binding.RLEmail.setOnClickListener {
            val email = resources.getString(R.string.email_tag)
            val intent = Intent(Intent.ACTION_SEND)
            val recipients = arrayOf(email)
            intent.putExtra(Intent.EXTRA_EMAIL, recipients)
            intent.type = "text/html"
            intent.`package` = "com.google.android.gm"
            startActivity(Intent.createChooser(intent, "Send mail"))
        }
    }


}*/
