package com.example.allinonestatussaver.ui.activity.socialActivities

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.util.Patterns
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.adapter.StoriesListAdapter
import com.example.allinonestatussaver.adapter.UserListAdapter
import com.example.allinonestatussaver.api.CommonClassForAPI
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.interfaces.UserListInterface
import com.example.allinonestatussaver.model.Edge
import com.example.allinonestatussaver.model.EdgeSidecarToChildren
import com.example.allinonestatussaver.model.ResponseModel
import com.example.allinonestatussaver.model.story.FullDetailModel
import com.example.allinonestatussaver.model.story.TrayModel
import com.example.allinonestatussaver.util.AppLangSessionManager
import com.example.allinonestatussaver.util.SharePrefs
import com.example.allinonestatussaver.util.Utils
import com.example.allinonestatussaver.util.Utils_status
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryInsta
import com.example.allinonestatussaver.util.Utils_status.createFileFolder
import com.example.allinonestatussaver.util.Utils_status.startDownload
import com.facebook.ads.InterstitialAd
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import io.reactivex.observers.DisposableObserver
import java.io.File
import java.lang.reflect.Type
import java.net.MalformedURLException
import java.net.URI
import java.net.URL
import java.util.Locale
import android.content.Intent as Intent1

class InstagramActivity : AppCompatActivity(), UserListInterface {

    private var binding: ActivityFacebookBinding? = null
    private var activity: InstagramActivity? = null
    var context: Context? = null
    private var clipBoard: ClipboardManager? = null
    var commonClassForAPI: CommonClassForAPI? = null
    private var PhotoUrl: String? = null
    private var VideoUrl: String? = null
    private var mInterstitialAd: InterstitialAd? = null
    var appLangSessionManager: AppLangSessionManager? = null
    var userListAdapter: UserListAdapter? = null
    var storiesListAdapter: StoriesListAdapter? = null

    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFacebookBinding.inflate(layoutInflater)

        appLangSessionManager = AppLangSessionManager(activity)
        setLocale(appLangSessionManager!!.getLanguage())
        commonClassForAPI = CommonClassForAPI.getInstance(activity)
        createFileFolder()




       val name = intent.getStringExtra("title")
       binding?.mainTitle?.setText(name)

        // AdsUtils.showGoogleBannerAd(this@InstagramActivity, binding.adView)
        //  InterstitialAdsINIT()
        // initViews()
    }
//    val name = intent.getStringExtra("title")
//    binding?.mainTitle?.text = name




    protected override fun onResume() {
        super.onResume()
        activity = this
        context = activity
        assert(activity != null)
        clipBoard = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
        PasteText()
    }

    private fun initViews() {
        clipBoard = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
        binding?.backArrow?.setOnClickListener(View.OnClickListener { onBackPressed() })
        //  binding.imInfo.setOnClickListener(View.OnClickListener {
        // binding.layoutHowTo.LLHowToLayout.setVisibility(
        View.VISIBLE
        //   )
        //  })
        /*   activity?.let {
            Glide.with(it)
                .load(R.drawable.insta1)
                .into(binding.layoutHowTo.imHowto1)
        }
        activity?.let {
            Glide.with(it)
                .load(R.drawable.insta2)
                .into(binding.layoutHowTo.imHowto2)
        }
        activity?.let {
            Glide.with(it)
                .load(R.drawable.insta3)
                .into(binding.layoutHowTo.imHowto3)
        }
        activity?.let {
            Glide.with(it)
                .load(R.drawable.insta4)
                .into(binding.layoutHowTo.imHowto4)
        }
        binding.layoutHowTo.tvHowTo1.setText(getResources().getString(R.string.opn_insta))
        binding.layoutHowTo.tvHowTo3.setText(getResources().getString(R.string.opn_insta))
        if (!SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISSHOWHOWTOINSTA)) {
            SharePrefs.getInstance(activity).putBoolean(SharePrefs.ISSHOWHOWTOINSTA, true)
            binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE)
        } else {
            binding.layoutHowTo.LLHowToLayout.setVisibility(View.GONE)

        }*/
        val name = intent.getStringExtra("Name")
        binding?.mainTitle?.setText(name)


        binding?.download?.setOnClickListener { v ->
            val LL: String = binding?.etText?.getText().toString()
            if (LL == "") {
                Utils_status.setToast(activity, getResources().getString(R.string.enter_url))
            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
                Utils_status.setToast(activity, getResources().getString(R.string.enter_valid_url))
            } else {
                GetInstagramData()
//                showInterstitial()
            }
        }
        binding?.paste?.setOnClickListener { v -> PasteText() }
        binding?.header?.setOnClickListener { v ->
            Utils_status.OpenApp(
                activity,
                "com.instagram.android"
            )
        }
//        val mLayoutManager = GridLayoutManager(getApplicationContext(), 1)
//        binding.RVUserList.setLayoutManager(mLayoutManager)
//        binding.RVUserList.setNestedScrollingEnabled(false)
//        mLayoutManager.setOrientation(RecyclerView.HORIZONTAL)
//        if (SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISINSTALOGIN)) {
//            layoutCondition()
//            callStoriesApi()
//            binding.SwitchLogin.setChecked(true)
//        } else {
//            binding.SwitchLogin.setChecked(false)
//        }
//        binding.tvLogin.setOnClickListener(View.OnClickListener {
//            val intent = Intent(
//                activity,
//                LoginActivity::class.java
//            )
//            startActivityForResult(intent, 100)
//        })
        binding?.header?.setOnClickListener(View.OnClickListener {
            if (!SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISINSTALOGIN)) {
//                val intent = Intent(
//                    activity,
//                    LoginActivity::class.java
//                )
                startActivityForResult(intent, 100)
            } else {
                val ab = AlertDialog.Builder(activity)
                ab.setPositiveButton(
                    getResources().getString(R.string.yes),
                    object : DialogInterface.OnClickListener {
                        override fun onClick(dialog: DialogInterface, id: Int) {
                            SharePrefs.getInstance(activity)
                                .putBoolean(SharePrefs.ISINSTALOGIN, false)
                            SharePrefs.getInstance(activity).putString(SharePrefs.COOKIES, "")
                            SharePrefs.getInstance(activity).putString(SharePrefs.CSRF, "")
                            SharePrefs.getInstance(activity).putString(SharePrefs.SESSIONID, "")
                            SharePrefs.getInstance(activity).putString(SharePrefs.USERID, "")
//                            if (SharePrefs.getInstance(activity)
//                                    .getBoolean(SharePrefs.ISINSTALOGIN)
//                            ) {
//                                binding.SwitchLogin.setChecked(true)
//                            } else {
//                                binding.SwitchLogin.setChecked(false)
//                                binding.RVUserList.setVisibility(View.GONE)
//                                binding.RVStories.setVisibility(View.GONE)
//                                binding.tvViewStories.setText(
//                                    activity!!.getResources().getText(R.string.view_stories)
//                                )
//                                binding.tvLogin.setVisibility(View.VISIBLE)
//                            }
//                            dialog.cancel()

                            //

                        }
                    })
                ab.setNegativeButton(
                    getResources().getString(R.string.cancel),
                    object : DialogInterface.OnClickListener {
                        override fun onClick(dialog: DialogInterface, id: Int) {
                            dialog.cancel()
                        }
                    })
                val alert = ab.create()
                alert.setTitle(getResources().getString(R.string.do_u_want_to_download_media_from_pvt))
                alert.show()
            }
        })
    }
    //}


//        val mLayoutManager1 = GridLayoutManager(getApplicationContext(), 3)
//        binding.RVStories.setLayoutManager(mLayoutManager1)
//        binding.RVStories.setNestedScrollingEnabled(false)
//        mLayoutManager1.setOrientation(RecyclerView.VERTICAL)


    // ////}

    //    fun layoutCondition() {
//        binding.tvViewStories.setText(activity?.getResources()?.getString(R.string.stories))
//        binding.tvLogin.setVisibility(View.GONE)
//    }
//
    fun GetInstagramData() {
        try {
            createFileFolder()
            val url = URL(binding?.etText?.getText().toString())
            val host = url.host
            Log.e("initViews: ", host)
            if (host == "www.instagram.com") {
                callDownload(binding?.etText?.getText().toString())
            } else {
                Utils_status.setToast(
                    activity,
                    getResources().getString(R.string.enter_valid_url)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    fun PasteText() {
        try {
            binding?.etText?.setText("")
            val CopyIntent: String? = getIntent().getStringExtra("CopyIntent")
            if (CopyIntent == "") {
                if (!clipBoard!!.hasPrimaryClip()) {
                } else if (!clipBoard!!.primaryClipDescription!!
                        .hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
                ) {
                    if (clipBoard!!.primaryClip!!.getItemAt(0).text.toString()
                            .contains("instagram.com")
                    ) {
                        binding?.etText?.setText(clipBoard!!.primaryClip!!.getItemAt(0).text.toString())
                    }
                } else {
                    val item: ClipData.Item = clipBoard!!.primaryClip!!.getItemAt(0)
                    if (item.getText().toString().contains("instagram.com")) {
                        binding?.etText?.setText(item.getText().toString())
                    }
                }
            } else {
                if (CopyIntent != null) {
                    if (CopyIntent.contains("instagram.com")) {
                        binding?.etText?.setText(CopyIntent)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getUrlWithoutParameters(url: String): String {
        return try {
            val uri = URI(url)
            URI(
                uri.scheme,
                uri.authority,
                uri.path,
                null,  // Ignore the query part of the input url
                uri.fragment
            ).toString()
        } catch (e: Exception) {
            e.printStackTrace()
            Utils_status.setToast(
                activity,
                getResources().getString(R.string.enter_valid_url)
            )
            ""
        }
    }

    fun callDownload(Url: String) {
        var UrlWithoutQP = getUrlWithoutParameters(Url)
        UrlWithoutQP = "$UrlWithoutQP?__a=1"
        try {
            val utils = Utils_status(activity)
            if (utils.isNetworkAvailable()) {
                if (commonClassForAPI != null) {
                    Utils_status.showProgressDialog(activity)
                    commonClassForAPI!!.callResult(
                        instaObserver, UrlWithoutQP,
                        "ds_user_id=" + SharePrefs.getInstance(activity)
                            .getString(SharePrefs.USERID) + "; sessionid=" + SharePrefs.getInstance(
                            activity
                        ).getString(SharePrefs.SESSIONID)
                    )
                }
            } else {
                Utils_status.setToast(
                    activity,
                    getResources().getString(R.string.no_net_conn)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    val instaObserver: DisposableObserver<JsonObject?> =
        object : DisposableObserver<JsonObject?>() {
            override fun onNext(versionList: JsonObject) {
                Utils_status.hideProgressDialog(activity)
                try {
                    Log.e("onNext: ", versionList.toString())
                    val listType: Type =
                        object : TypeToken<ResponseModel?>() {}.getType()
                    val responseModel: ResponseModel =
                        Gson().fromJson(versionList.toString(), listType)
                    val edgeSidecarToChildren: EdgeSidecarToChildren? =
                        responseModel.getGraphql()?.getShortcode_media()
                            ?.getEdge_sidecar_to_children()
                    if (edgeSidecarToChildren != null) {
                        val edgeArrayList: List<Edge?>? =
                            edgeSidecarToChildren.getEdges()
                        if (edgeArrayList != null) {
                            for (i in edgeArrayList.indices) {
                                if (edgeArrayList?.get(i)?.getNode()
                                        ?.isIs_video() == true
                                ) {
                                    VideoUrl = edgeArrayList?.get(i)!!.getNode()
                                        ?.getVideo_url()
                                    startDownload(
                                        VideoUrl,
                                        RootDirectoryInsta,
                                        activity,
                                        getVideoFilenameFromURL(VideoUrl)
                                    )
                                    binding?.etText?.setText("")
                                    VideoUrl = ""
                                } else {
                                    PhotoUrl = edgeArrayList[i]?.getNode()
                                        ?.getDisplay_resources()
                                        ?.get(
                                            edgeArrayList[i]?.getNode()
                                                ?.getDisplay_resources()
                                                ?.size?.minus(1)!!
                                        )?.getSrc()
                                    startDownload(
                                        PhotoUrl,
                                        RootDirectoryInsta,
                                        activity,
                                        getImageFilenameFromURL(PhotoUrl)
                                    )
                                    PhotoUrl = ""
                                    binding?.etText?.setText("")
                                }
                            }
                        }
                    } else {
                        val isVideo: Boolean =
                            responseModel.getGraphql()?.getShortcode_media()
                                ?.isIs_video() == true

                        if (isVideo) {
                            VideoUrl =
                                responseModel.getGraphql()?.getShortcode_media()
                                    ?.getVideo_url()
                            //new DownloadFileFromURL().execute(VideoUrl,getFilenameFromURL(VideoUrl));
                            startDownload(
                                VideoUrl,
                                RootDirectoryInsta,
                                activity,
                                getVideoFilenameFromURL(VideoUrl)
                            )
                            VideoUrl = ""
                            binding?.etText?.setText("")
                        } else {
                            PhotoUrl = responseModel.getGraphql()?.getShortcode_media()
                                ?.getDisplay_resources()
                                ?.get(
                                    responseModel.getGraphql()!!.getShortcode_media()
                                        ?.getDisplay_resources()?.size?.minus(1)!!
                                )?.getSrc()
                            startDownload(
                                PhotoUrl,
                                RootDirectoryInsta,
                                activity,
                                getImageFilenameFromURL(PhotoUrl)
                            )
                            PhotoUrl = ""
                            binding?.etText?.setText("")
                            // new DownloadFileFromURL().execute(PhotoUrl,getFilenameFromURL(PhotoUrl));
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(e: Throwable) {
                Utils_status.hideProgressDialog(activity)
                e.printStackTrace()
            }

            override fun onComplete() {
                Utils_status.hideProgressDialog(activity)
            }
        }

    fun getImageFilenameFromURL(url: String?): String {
        return try {
            File(URL(url).path.toString()).name
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            System.currentTimeMillis().toString() + ".png"
        }
    }

    fun getVideoFilenameFromURL(url: String?): String {
        return try {
            File(URL(url).path.toString()).name
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            System.currentTimeMillis().toString() + ".mp4"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instaObserver.dispose()
    }

//    protected override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        try {
//            super.onActivityResult(requestCode, resultCode, data)
//            if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
//                val requiredValue: String? = data?.getStringExtra("key")
//                if (SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISINSTALOGIN)) {
//                    binding.SwitchLogin.setChecked(true)
//                    layoutCondition()
//                    callStoriesApi()
//                } else {
//                    binding.SwitchLogin.setChecked(false)
//                }
//            }
//        } catch (ex: Exception) {
//            ex.printStackTrace()
//        }
//    }

    fun setLocale(lang: String?) {
        val myLocale = Locale(lang)
        val res: Resources = getResources()
        val dm: DisplayMetrics = res.displayMetrics
        val conf = res.configuration
        conf.locale = myLocale
        res.updateConfiguration(conf, dm)
    }

    //InterstitialAd : Start
//            fun InterstitialAdsINIT() {
//                MobileAds.initialize(this, object : OnInitializationCompleteListener,
//                    com.google.android.gms.ads.initialization.OnInitializationCompleteListener {
//                    override fun onInitializationComplete(initializationStatus: InitializationStatus?) {}
//                    override fun onInitializationComplete(p0: InitializationStatus) {
//                        TODO("Not yet implemented")
//                    }
//                })
//        mInterstitialAd = InterstitialAd(this)
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_interstitial_ad))
//        mInterstitialAd.loadAd(Builder().build())
//        mInterstitialAd!!.setAdListener(object : AdListener() {
//            fun onAdLoaded() {
//                // Code to be executed when an ad finishes loading.
//            }
//
//            fun onAdFailedToLoad(errorCode: Int) {
//                // Code to be executed when an ad request fails.
//            }
//
//            fun onAdOpened() {
//                // Code to be executed when the ad is displayed.
//            }
//
//            fun onAdClicked() {
//
//                // Code to be executed when the user clicks on an ad.
//            }
//
//            fun onAdLeftApplication() {
//                // Code to be executed when the user has left the app.
//            }
//
//            fun onAdClosed() {
//                // Code to be executed when the interstitial ad is closed.
//            }
//        })
//    }

//                fun showInterstitial() {
//                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
//                        mInterstitialAd!!.show()
//                    }
//                }

    //InterstitialAd : End
//    private fun callStoriesApi() {
//        try {
//            val utils =  Utils_status(activity)
//            if (utils.isNetworkAvailable()) {
//                if (commonClassForAPI != null) {
//                    binding.prLoadingBar.setVisibility(View.VISIBLE)
//                    commonClassForAPI!!.getStories(
//                        storyObserver,
//                        "ds_user_id=" + SharePrefs.getInstance(activity)
//                            .getString(SharePrefs.USERID) + "; sessionid=" + SharePrefs.getInstance(
//                            activity
//                        ).getString(SharePrefs.SESSIONID)
//                    )
//                }
//            } else {
//                Utils_status.setToast(
//                    activity, activity
//                        ?.getResources()!!.getString(R.string.no_net_conn)
//                )
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

//    private val storyObserver: DisposableObserver<StoryModel?> =
//        object : DisposableObserver<StoryModel?>() {
//            override fun onNext(response: StoryModel) {
//                binding.RVUserList.setVisibility(View.VISIBLE)
//                binding.prLoadingBar.setVisibility(View.GONE)
//                try {
//                    userListAdapter =
//                        activity?.let { UserListAdapter(it, response.getTray(), activity!!) }
//                    binding.RVUserList.setAdapter(userListAdapter)
//                    userListAdapter!!.notifyDataSetChanged()
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                }
//            }
//
//            override fun onError(e: Throwable) {
//                binding.prLoadingBar.setVisibility(View.GONE)
//                e.printStackTrace()
//            }

//            override fun onComplete() {
//                binding.prLoadingBar.setVisibility(View.GONE)
//            }
//        }

//    fun userListClick(position: Int, trayModel: TrayModel) {
//        callStoriesDetailApi(
//            java.lang.String.valueOf(
//                trayModel.getUser()!!.getPk()
//            )
//        )
//    }

    override fun userListClick(position: Int, trayModel: TrayModel?) {
        TODO("Not yet implemented")
    }

    override fun InterstitialAd(instagramActivity: InstagramActivity): InterstitialAd {
        TODO("Not yet implemented")
    }


    private fun callStoriesDetailApi(UserId: String) {
        try {
            val utils = Utils(activity)
            if (utils.isNetworkAvailable()) {
                if (commonClassForAPI != null) {
                    //  binding.prLoadingBar.setVisibility(View.VISIBLE)
                    commonClassForAPI!!.getFullDetailFeed(
                        storyDetailObserver,
                        UserId,
                        "ds_user_id=" + SharePrefs.getInstance(activity)
                            .getString(SharePrefs.USERID) + "; sessionid=" + SharePrefs.getInstance(
                            activity
                        ).getString(SharePrefs.SESSIONID)
                    )
                }
            } else {
                Utils_status.setToast(
                    activity, activity?.getResources()?.getString(R.string.no_net_conn)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    //
//
    private val storyDetailObserver: DisposableObserver<FullDetailModel?> =
        object : DisposableObserver<FullDetailModel?>() {
            override fun onNext(response: FullDetailModel) {
                //  binding.RVUserList.setVisibility(View.VISIBLE)
                //  binding.prLoadingBar.setVisibility(View.GONE)
                try {
                    storiesListAdapter =
                        activity?.let { StoriesListAdapter(it, response.getReel_feed()?.getItems()) }
                    //binding.RVStories.setAdapter(storiesListAdapter)
                    storiesListAdapter?.notifyDataSetChanged()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(e: Throwable) {
                //   binding.prLoadingBar.setVisibility(View.GONE)
                e.printStackTrace()
            }

            override fun onComplete() {
                TODO("Not yet implemented")
            }

//            override fun onComplete() { binding.prLoadingBar.setVisibility(View.GONE)
//            }


//                fun userListClick(position: Int, trayModel: TrayModel?) {
//                    TODO("Not yet implemented")
//                }
//
//                fun InterstitialAd(instagramActivity: InstagramActivity): InterstitialAd {
//                    TODO("Not yet implemented")
        }
}
