package com.example.allinonestatussaver.ui.frag

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.adapter.WhatsappStatusAdapter
import com.example.allinonestatussaver.databinding.FragmentWhatsappImageBinding
import com.example.allinonestatussaver.model.WhatsappStatusModel
import java.io.File
import java.util.Arrays

class WhatsappImageFragment : Fragment() {
    private var binding: FragmentWhatsappImageBinding? = null

    private lateinit var allfiles: Array<File>
    private var statusModelArrayList: ArrayList<WhatsappStatusModel>? = null
    private var whatsappStatusAdapter: WhatsappStatusAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_whatsapp_image, container, false)
        initViews()
        return binding?.root
    }

    private fun initViews() {
        statusModelArrayList = ArrayList()
        getData()
        binding?.swiperefresh?.setOnRefreshListener {
            statusModelArrayList?.clear()
            getData()
            binding?.swiperefresh?.isRefreshing = false
        }
    }

    private fun getData() {
        var whatsappStatusModel: WhatsappStatusModel
        val targetPath =
            Environment.getExternalStorageDirectory().absolutePath + "/WhatsApp/Media/.Statuses"
        val targetDirector = File(targetPath)
        allfiles = targetDirector.listFiles() ?: emptyArray()
        val targetPathBusiness =
            Environment.getExternalStorageDirectory().absolutePath + "/WhatsApp Business/Media/.Statuses"
        val targetDirectorBusiness = File(targetPathBusiness)
        val allfilesBusiness = targetDirectorBusiness.listFiles() ?: emptyArray()
        try {
            Arrays.sort(allfiles) { o1, o2 ->
                when {
                    (o1 as File).lastModified() > (o2 as File).lastModified() -> -1
                    o1.lastModified() < o2.lastModified() -> 1
                    else -> 0
                }
            }

            for (i in allfiles.indices) {
                val file = allfiles[i]
                if (Uri.fromFile(file).toString().endsWith(".png") || Uri.fromFile(file).toString()
                        .endsWith(".jpg")
                ) {
                    whatsappStatusModel = WhatsappStatusModel(
                        "WhatsStatus: " + (i + 1),
                        Uri.fromFile(file),
                        allfiles[i].absolutePath,
                        file.name
                    )
                    statusModelArrayList?.add(whatsappStatusModel)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            Arrays.sort(allfilesBusiness) { o1, o2 ->
                when {
                    (o1 as File).lastModified() > (o2 as File).lastModified() -> -1
                    o1.lastModified() < o2.lastModified() -> 1
                    else -> 0
                }
            }

            for (i in allfilesBusiness.indices) {
                val file = allfilesBusiness[i]
                if (Uri.fromFile(file).toString().endsWith(".png") || Uri.fromFile(file).toString()
                        .endsWith(".jpg")
                ) {
                    whatsappStatusModel = WhatsappStatusModel(
                        "WhatsStatusB: " + (i + 1),
                        Uri.fromFile(file),
                        allfilesBusiness[i].absolutePath,
                        file.name
                    )
                    statusModelArrayList?.add(whatsappStatusModel)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (statusModelArrayList?.size != 0) {
            binding?.tvNoResult?.visibility = View.GONE
        } else {
            binding?.tvNoResult?.visibility = View.VISIBLE
        }
        whatsappStatusAdapter = WhatsappStatusAdapter(requireActivity(), statusModelArrayList ?: ArrayList())
        binding?.rvFileList?.adapter = whatsappStatusAdapter
    }
}

