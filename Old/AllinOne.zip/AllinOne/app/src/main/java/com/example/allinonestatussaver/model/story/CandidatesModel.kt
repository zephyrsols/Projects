package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class CandidatesModel : Serializable {
    @SerializedName("width")
    var width = 0

    @SerializedName("height")
    var height = 0

    @SerializedName("url")
    var url: String? = null

    @SerializedName("scans_profile")
    var scans_profile: String? = null
}