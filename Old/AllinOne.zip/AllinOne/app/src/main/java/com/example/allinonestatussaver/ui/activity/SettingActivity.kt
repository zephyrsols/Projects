package com.example.allinonestatussaver.ui.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.databinding.ActivitySettingBinding
import com.example.allinonestatussaver.ui.activity.socialActivities.FacebookActivity

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backArrow.setOnClickListener{(onBackPressed())}
        binding.language.setOnClickListener{(callLanguageActivity())}




    }

    private fun callLanguageActivity() {
        val i = Intent(this,LanguageActivity::class.java)
        startActivity(i)

    }

}