package com.example.allinonestatussaver.ui.activity.socialActivities

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.api.CommonClassForAPI
import com.example.allinonestatussaver.databinding.ActivityFacebookBinding
import com.example.allinonestatussaver.model.TwitterResponse
import com.example.allinonestatussaver.util.AppLangSessionManager
import com.example.allinonestatussaver.util.Utils
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAd
import com.facebook.ads.InterstitialAdListener
import io.reactivex.observers.DisposableObserver
import java.io.File
import java.net.MalformedURLException
import java.net.URL
import java.util.Locale

class TwitterActivity : AppCompatActivity() {
    private var binding: ActivityFacebookBinding? = null
    var activity: TwitterActivity? = null
    var commonClassForAPI: CommonClassForAPI? = null
    private var VideoUrl: String? = null
    private var clipBoard: ClipboardManager? = null
    var appLangSessionManager: AppLangSessionManager? = null
    private var interstitialAd: InterstitialAd? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layoutInflater: LayoutInflater? = null
        binding = ActivityFacebookBinding.inflate(
            layoutInflater!!
        )
        commonClassForAPI = CommonClassForAPI.getInstance(activity)
        Utils.createFileFolder()
        initViews()
        appLangSessionManager = AppLangSessionManager(activity)
        setLocale(appLangSessionManager!!.language)

//        AdsUtils.showFBBannerAdRect(activity,binding.bannerContainer);
//        FBInterstitialAdsINIT();
    }

    override fun onResume() {
        super.onResume()
        activity = this
        assert(activity != null)
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        PasteText()
    }

    private fun initViews() {
        clipBoard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        binding!!.backArrow.setOnClickListener { onBackPressed() }
        //        binding.imInfo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//            }
//        });


//        Glide.with(activity)
//                .load(R.drawable.tw1)
//                .into(binding.layoutHowTo.imHowto1);
//
//        Glide.with(activity)
//                .load(R.drawable.tw2)
//                .into(binding.layoutHowTo.imHowto2);
//
//        Glide.with(activity)
//                .load(R.drawable.tw3)
//                .into(binding.layoutHowTo.imHowto3);
//
//        Glide.with(activity)
//                .load(R.drawable.tw4)
//                .into(binding.layoutHowTo.imHowto4);
//
//
//
//        binding.layoutHowTo.tvHowTo1.setText(getResources().getString(R.string.open_twitter));
//        binding.layoutHowTo.tvHowTo3.setText(getResources().getString(R.string.open_twitter));
//        if (!SharePrefs.getInstance(activity).getBoolean(SharePrefs.ISSHOWHOWTOTWITTER)) {
//            SharePrefs.getInstance(activity).putBoolean(SharePrefs.ISSHOWHOWTOTWITTER,true);
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.VISIBLE);
//        }else {
//            binding.layoutHowTo.LLHowToLayout.setVisibility(View.GONE);
//        }
        binding!!.download.setOnClickListener { v: View? ->
            val LL = binding!!.etText.text.toString()
            if (LL == "") {
                Utils.setToast(activity, resources.getString(R.string.enter_url))
            } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
                Utils.setToast(activity, resources.getString(R.string.enter_valid_url))
            } else {
                Utils.showProgressDialog(activity)
                GetTwitterData()
                showInterstitial()
            }
        }
        binding!!.paste.setOnClickListener { v: View? -> PasteText() }

//        binding.LLOpenTwitter.setOnClickListener(v -> {
//            Utils.OpenApp(activity,"com.twitter.android");
//        });
    }

    private fun GetTwitterData() {
        try {
            Utils.createFileFolder()
            val url = URL(binding!!.etText.text.toString())
            val host = url.host
            if (host.contains("twitter.com")) {
                val id = getTweetId(binding!!.etText.text.toString())
                if (id != null) {
                    callGetTwitterData(id.toString())
                }
            } else {
                Utils.setToast(activity, resources.getString(R.string.enter_url))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getTweetId(s: String): Long? {
        return try {
            val split = s.split("\\/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            val id = split[5].split("\\?".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray()[0]
            id.toLong()
        } catch (e: Exception) {
            Log.d("TAG", "getTweetId: " + e.localizedMessage)
            null
        }
    }

    private fun PasteText() {
        try {
            binding!!.etText.setText("")
            val CopyIntent = intent.getStringExtra("CopyIntent")
            if (CopyIntent == "") {
                if (!clipBoard!!.hasPrimaryClip()) {
                } else if (!clipBoard!!.primaryClipDescription!!
                        .hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
                ) {
                    if (clipBoard!!.primaryClip!!.getItemAt(0).text.toString()
                            .contains("twitter.com")
                    ) {
                        binding!!.etText.setText(clipBoard!!.primaryClip!!.getItemAt(0).text.toString())
                    }
                } else {
                    val item = clipBoard!!.primaryClip!!.getItemAt(0)
                    if (item.text.toString().contains("twitter.com")) {
                        binding!!.etText.setText(item.text.toString())
                    }
                }
            } else {
                if (CopyIntent!!.contains("twitter.com")) {
                    binding!!.etText.setText(CopyIntent)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun callGetTwitterData(id: String) {
        val URL = "https://twittervideodownloaderpro.com/twittervideodownloadv2/index.php"
        try {
            val utils = Utils(activity)
            if (utils.isNetworkAvailable) {
                if (commonClassForAPI != null) {
                    Utils.showProgressDialog(activity)
                    commonClassForAPI!!.callTwitterApi(observer, URL, id)
                }
            } else {
                Utils.setToast(activity, resources.getString(R.string.no_net_conn))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private val observer: DisposableObserver<TwitterResponse?> =
        object : DisposableObserver<TwitterResponse?>() {
            override fun onNext(twitterResponse: TwitterResponse) {
                Utils.hideProgressDialog(activity)
                try {
                    VideoUrl = twitterResponse.videos!![0].url
                    if (twitterResponse.videos!![0].type == "image") {
                        Utils.startDownload(
                            VideoUrl,
                            Utils.RootDirectoryTwitter,
                            activity,
                            getFilenameFromURL(VideoUrl, "image")
                        )
                        binding!!.etText.setText("")
                    } else {
                        VideoUrl = twitterResponse.videos!![twitterResponse.videos!!.size - 1].url
                        Utils.startDownload(
                            VideoUrl,
                            Utils.RootDirectoryTwitter,
                            activity,
                            getFilenameFromURL(VideoUrl, "mp4")
                        )
                        binding!!.etText.setText("")
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Utils.setToast(activity, resources.getString(R.string.no_media_on_tweet))
                }
            }

            override fun onError(e: Throwable) {
                Utils.hideProgressDialog(activity)
                e.printStackTrace()
            }

            override fun onComplete() {
                Utils.hideProgressDialog(activity)
            }
        }

    fun getFilenameFromURL(url: String?, type: String): String {
        return if (type == "image") {
            try {
                File(URL(url).path).name + ""
            } catch (e: MalformedURLException) {
                e.printStackTrace()
                System.currentTimeMillis().toString() + ".jpg"
            }
        } else {
            try {
                File(URL(url).path).name + ""
            } catch (e: MalformedURLException) {
                e.printStackTrace()
                System.currentTimeMillis().toString() + ".mp4"
            }
        }
    }

    fun setLocale(lang: String?) {
        val myLocale = Locale(lang)
        val res = resources
        val dm = res.displayMetrics
        val conf = res.configuration
        conf.locale = myLocale
        res.updateConfiguration(conf, dm)
    }

    //FB INTERSTITIAL ADS : STARTED
    fun FBInterstitialAdsINIT() {
        interstitialAd =
            InterstitialAd(this, resources.getString(R.string.fb_placement_interstitial_id))
        // Set listeners for the Interstitial Ad
        interstitialAd!!.setAdListener(object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {
                // Interstitial ad displayed callback
                Log.e(ContentValues.TAG, "Interstitial ad displayed.")
            }

            override fun onInterstitialDismissed(ad: Ad) {
                // Interstitial dismissed callback
                Log.e(ContentValues.TAG, "Interstitial ad dismissed.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Ad error callback
            }

            override fun onAdLoaded(ad: Ad) {
                // Interstitial ad is loaded and ready to be displayed
                Log.d(ContentValues.TAG, "Interstitial ad is loaded and ready to be displayed!")
                // Show the ad
            }

            override fun onAdClicked(ad: Ad) {
                // Ad clicked callback
                Log.d(ContentValues.TAG, "Interstitial ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Ad impression logged callback
                Log.d(ContentValues.TAG, "Interstitial ad impression logged!")
            }
        })

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown
        interstitialAd!!.loadAd()
    }

    private fun showInterstitial() {
        if (interstitialAd != null && interstitialAd!!.isAdLoaded) {
            interstitialAd!!.show()
        }
    } //FB INTERSTITIAL ADS : END
}