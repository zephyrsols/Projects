package com.example.allinonestatussaver.util

class Events {
    class RefreshLanguageStrings
}
