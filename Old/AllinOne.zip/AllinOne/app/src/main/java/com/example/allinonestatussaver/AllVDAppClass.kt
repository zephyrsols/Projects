package com.example.allinonestatussaver

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.StrictMode
import androidx.appcompat.app.AppCompatDelegate


class AllVDAppClass : Application(){

//    val nativeAdLang: MutableLiveData<NativeAd> = MutableLiveData()
//    val nativeAdMain: MutableLiveData<NativeAd?> = MutableLiveData()
//    val nativeAdSmall: MutableLiveData<NativeAd> = MutableLiveData()
//    val nativeAdLarge: MutableLiveData<NativeAd> = MutableLiveData()
//    val nativeAdBoarding: MutableLiveData<NativeAd> = MutableLiveData()



    var intent: Intent? = null


    override fun onCreate() {
        super.onCreate()
        instance = this


//        app_class = this@AllVDAppClass
//        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
//        OpenApp(this)
//        // Log the Mobile Ads SDK version.
//        Log.d(TAG, "Google Mobile Ads SDK Version: " + MobileAds.getVersion())
//        MobileAds.initialize(this) { }

//        applicationInstance = this@AllVDAppClass
//        instance = this@AllVDAppClass




//        app_class = this@AllVDAppClass
    }


    companion object {
        lateinit var instance: AllVDAppClass
        var isAlready = false

        @SuppressLint("StaticFieldLeak")
        @get:Synchronized
        var app_class: AllVDAppClass? = null
            private set
        private const val TAG = "TextOnPhotos"
        private const val LOG_TAG = "AppOpenAdManager"


        const val PRO_VERSION_PRODUCT_ID = "pro_version"
        val context: Context get() = (instance as AllVDAppClass).applicationContext
        var applicationInstance: AllVDAppClass? = null

    }


}
