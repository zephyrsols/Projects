package com.example.allinonestatussaver.model.story

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class HDProfileModel : Serializable {
    @SerializedName("width")
    var width = 0

    @SerializedName("height")
    var height = 0

    @SerializedName("url")
    var url: String? = null
}