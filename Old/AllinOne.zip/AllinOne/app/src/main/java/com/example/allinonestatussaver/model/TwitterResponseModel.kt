package com.example.allinonestatussaver.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class TwitterResponseModel : Serializable {
    @SerializedName("source")
    var source: String? = null

    @SerializedName("text")
    var text: String? = null

    @SerializedName("thumb")
    var thumb: String? = null

    @SerializedName("type")
    var type: String? = null

    @SerializedName("duration")
    var duration = 0

    @SerializedName("bitrate")
    var bitrate = 0

    @SerializedName("url")
    var url: String? = null

    @SerializedName("size")
    var size = 0
}