package com.example.allinonestatussaver.ui.frag

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.allinonestatussaver.R
import com.example.allinonestatussaver.adapter.FileListAdapter
import com.example.allinonestatussaver.databinding.ActivityAppPermissionBinding.inflate
import com.example.allinonestatussaver.databinding.FragmentHistoryBinding
import com.example.allinonestatussaver.interfaces.FileListClickInterface
import com.example.allinonestatussaver.ui.activity.FullViewActivity
import com.example.allinonestatussaver.ui.activity.GalleryActivity
import com.example.allinonestatussaver.util.Utils_status.RootDirectoryLikeeShow
import java.io.File



class LikeeDownloadedFragment : Fragment(), FileListClickInterface {
    private lateinit var binding: FragmentHistoryBinding
    private var fileListAdapter: FileListAdapter? = null
    private var fileArrayList: ArrayList<File>? = null
    private var activity: GalleryActivity? = null
    override fun onAttach(_context: Context) {
        super.onAttach(_context)
        activity = _context as GalleryActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            val mParam1 = requireArguments().getString("m")
        }
    }

    override fun onResume() {
        super.onResume()
        activity = getActivity() as GalleryActivity?
        allFiles
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHistoryBinding.inflate(inflater, container, false)
        initViews()
        return binding.root
    }

    private fun initViews() {
        binding.swiperefresh.setOnRefreshListener {
            allFiles
            binding.swiperefresh.setRefreshing(false)
        }
    }

    private val allFiles: Unit
        private get() {
            fileArrayList = ArrayList()
            val files: Array<File> = RootDirectoryLikeeShow.listFiles()
            if (files != null) {
                for (file in files) {
                    fileArrayList!!.add(file)
                }
                fileListAdapter =
                    activity?.let { FileListAdapter(it, fileArrayList!!, this@LikeeDownloadedFragment) }
                binding.rvFileList.setAdapter(fileListAdapter)
            }
        }

    override fun getPosition(position: Int, file: File?) {
        val inNext = Intent(activity, FullViewActivity::class.java)
        inNext.putExtra("ImageDataFile", fileArrayList)
        inNext.putExtra("Position", position)
        activity?.startActivity(inNext)
    }

    companion object {
        fun newInstance(param1: String?): LikeeDownloadedFragment {
            val fragment = LikeeDownloadedFragment()
            val args = Bundle()
            args.putString("m", param1)
            fragment.arguments = args
            return fragment
        }
    }
}